import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User types
export const userTypes = ["customer", "client"] as const;
export type UserType = typeof userTypes[number];

// Base user table shared between customers and salon owners
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number").notNull(),
  userType: text("user_type", { enum: userTypes }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Customer profile details
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  gender: text("gender"),
  dateOfBirth: text("date_of_birth"),
  profileImage: text("profile_image"),
  walletBalance: integer("wallet_balance").default(0),
});

// Salon profile details
export const salons = pgTable("salons", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  pincode: text("pincode").notNull(),
  coverImage: text("cover_image"),
  profileImage: text("profile_image"),
  contactNumber: text("contact_number").notNull(),
  isVerified: boolean("is_verified").default(false),
  workingHours: jsonb("working_hours"),
  tags: text("tags").array(),
  rating: real("rating").default(0),
  totalRating: integer("total_rating").default(0),
  totalReviews: integer("total_reviews").default(0),
  location: jsonb("location"), // { lat: number, lng: number }
});

// Service categories
export const serviceCategories = pgTable("service_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon"),
  imageUrl: text("image_url"),
});

// Services offered by salons
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  salonId: integer("salon_id").notNull().references(() => salons.id),
  categoryId: integer("category_id").references(() => serviceCategories.id),
  name: text("name").notNull(),
  description: text("description"),
  price: integer("price").notNull(), // Stored in paisa/cents
  duration: integer("duration").notNull(), // In minutes
  imageUrl: text("image_url"),
  isPopular: boolean("is_popular").default(false),
  gender: text("gender"), // "male", "female", "unisex"
  tags: text("tags").array(),
});

// Service add-ons
export const addons = pgTable("addons", {
  id: serial("id").primaryKey(),
  serviceId: integer("service_id").notNull().references(() => services.id),
  name: text("name").notNull(),
  description: text("description"),
  price: integer("price").notNull(), // Stored in paisa/cents
  duration: integer("duration").notNull(), // In minutes
});

// Staff members working at salons
export const staff = pgTable("staff", {
  id: serial("id").primaryKey(),
  salonId: integer("salon_id").notNull().references(() => salons.id),
  name: text("name").notNull(),
  role: text("role").notNull(),
  bio: text("bio"),
  imageUrl: text("image_url"),
  specialities: text("specialities").array(),
});

// Time slots for appointments
export const timeSlots = pgTable("time_slots", {
  id: serial("id").primaryKey(),
  salonId: integer("salon_id").notNull().references(() => salons.id),
  staffId: integer("staff_id").references(() => staff.id),
  date: text("date").notNull(), // YYYY-MM-DD
  startTime: text("start_time").notNull(), // HH:MM
  endTime: text("end_time").notNull(), // HH:MM
  isAvailable: boolean("is_available").default(true),
});

// Booking status options
export const bookingStatuses = ["pending", "confirmed", "completed", "cancelled"] as const;
export type BookingStatus = typeof bookingStatuses[number];

// Bookings made by customers
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  bookingId: text("booking_id").notNull().unique(), // e.g. BK12345
  customerId: integer("customer_id").notNull().references(() => customers.id),
  salonId: integer("salon_id").notNull().references(() => salons.id),
  serviceId: integer("service_id").notNull().references(() => services.id),
  staffId: integer("staff_id").references(() => staff.id),
  addonIds: integer("addon_ids").array(),
  date: text("date").notNull(), // YYYY-MM-DD
  time: text("time").notNull(), // HH:MM
  status: text("status", { enum: bookingStatuses }).notNull().default('pending'),
  totalAmount: integer("total_amount").notNull(), // Stored in paisa/cents
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reviews and ratings
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  salonId: integer("salon_id").notNull().references(() => salons.id),
  bookingId: integer("booking_id").references(() => bookings.id),
  rating: integer("rating").notNull(), // 1-5
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Offers and promotions
export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  salonId: integer("salon_id").references(() => salons.id), // Null means platform-wide offer
  title: text("title").notNull(),
  description: text("description").notNull(),
  code: text("code").notNull(),
  discountType: text("discount_type").notNull(), // "percentage", "fixed"
  discountValue: integer("discount_value").notNull(), // Percentage or amount
  minAmount: integer("min_amount"), // Minimum cart value in paisa/cents
  maxDiscount: integer("max_discount"), // Maximum discount in paisa/cents
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true),
});

// Wallet transactions
export const walletTransactions = pgTable("wallet_transactions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  amount: integer("amount").notNull(), // Positive for credit, negative for debit
  description: text("description").notNull(),
  bookingId: integer("booking_id").references(() => bookings.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  type: text("type").notNull(), // "booking", "offer", "reminder", etc.
  linkUrl: text("link_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI chat sessions
export const chatSessions = pgTable("chat_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  messages: jsonb("messages").notNull(), // Array of chat messages
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schemas for data insertion

// User schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Customer schemas
export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true });
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

// Salon schemas
export const insertSalonSchema = createInsertSchema(salons).omit({ id: true, rating: true, totalRating: true, totalReviews: true });
export type InsertSalon = z.infer<typeof insertSalonSchema>;
export type Salon = typeof salons.$inferSelect;

// Service schemas
export const insertServiceSchema = createInsertSchema(services).omit({ id: true });
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;

// Booking schemas
export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, bookingId: true, createdAt: true, updatedAt: true });
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

// Review schemas
export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true, createdAt: true });
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

// Login schema
export const loginSchema = z.object({
  username: z.string().min(3, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});
