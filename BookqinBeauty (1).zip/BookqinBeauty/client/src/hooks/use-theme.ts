import { useState, useEffect } from 'react';
import { Theme, getSystemTheme, applyTheme, getSavedTheme } from '@/lib/theme';

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    // Use the saved theme or system preference
    return getSavedTheme() || getSystemTheme();
  });

  useEffect(() => {
    // Apply theme change to document
    applyTheme(theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return { theme, toggleTheme };
}
