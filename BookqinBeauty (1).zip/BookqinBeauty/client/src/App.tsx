import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

// Auth Pages
import Login from "@/pages/auth/login";
import Register from "@/pages/auth/register";
import ForgotPassword from "@/pages/auth/forgot-password";

// Customer Pages
import CustomerHome from "@/pages/customer/home";
import CustomerSalonProfile from "@/pages/customer/salon-profile";
import Booking from "@/pages/customer/booking";
import CustomerBookings from "@/pages/customer/bookings";
import Wallet from "@/pages/customer/wallet";
import CustomerProfile from "@/pages/customer/profile";
import AiStyle from "@/pages/customer/ai-style";

// Client Pages (Salon Owners)
// Using the existing salon page components but renaming the imports
import SalonDashboard from "@/pages/salon/dashboard";
import SalonBookings from "@/pages/salon/bookings";
import SalonServices from "@/pages/salon/services";
import SalonStaff from "@/pages/salon/staff";
import SalonEarnings from "@/pages/salon/earnings";
import SalonReviews from "@/pages/salon/reviews";
import SalonOwnerProfile from "@/pages/salon/profile";

// Other Components
import NotFound from "@/pages/not-found";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { AuthProvider } from "@/components/providers/AuthProvider";
import ProtectedRoute from "@/components/ProtectedRoute";

function App() {
  const [location] = useLocation();

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <TooltipProvider>
            <Switch>
              {/* Auth Routes */}
              <Route path="/auth/login" component={Login} />
              <Route path="/auth/register" component={Register} />
              <Route path="/auth/forgot-password" component={ForgotPassword} />
              <Route path="/login" component={Login} />
              <Route path="/register" component={Register} />

              {/* Customer Routes */}
              <Route path="/">
                <ProtectedRoute userType="customer" component={CustomerHome} />
              </Route>
              <Route path="/customer/home">
                <ProtectedRoute userType="customer" component={CustomerHome} />
              </Route>
              <Route path="/salon/:id">
                {(params) => (
                  <ProtectedRoute 
                    userType="customer" 
                    component={CustomerSalonProfile} 
                    salonId={params.id} 
                  />
                )}
              </Route>
              <Route path="/booking/:salonId/:serviceId">
                {(params) => (
                  <ProtectedRoute 
                    userType="customer" 
                    component={Booking} 
                    salonId={params.salonId}
                    serviceId={params.serviceId}
                  />
                )}
              </Route>
              <Route path="/bookings">
                <ProtectedRoute userType="customer" component={CustomerBookings} />
              </Route>
              <Route path="/customer/bookings">
                <ProtectedRoute userType="customer" component={CustomerBookings} />
              </Route>
              <Route path="/wallet">
                <ProtectedRoute userType="customer" component={Wallet} />
              </Route>
              <Route path="/customer/wallet">
                <ProtectedRoute userType="customer" component={Wallet} />
              </Route>
              <Route path="/profile">
                <ProtectedRoute userType="customer" component={CustomerProfile} />
              </Route>
              <Route path="/customer/profile">
                <ProtectedRoute userType="customer" component={CustomerProfile} />
              </Route>
              <Route path="/ai-style">
                <ProtectedRoute userType="customer" component={AiStyle} />
              </Route>
              <Route path="/customer/ai-style">
                <ProtectedRoute userType="customer" component={AiStyle} />
              </Route>

              {/* Client Routes (Salon Owners) */}
              <Route path="/client/dashboard">
                <ProtectedRoute userType="client" component={SalonDashboard} />
              </Route>
              <Route path="/client/bookings">
                <ProtectedRoute userType="client" component={SalonBookings} />
              </Route>
              <Route path="/client/services">
                <ProtectedRoute userType="client" component={SalonServices} />
              </Route>
              <Route path="/client/staff">
                <ProtectedRoute userType="client" component={SalonStaff} />
              </Route>
              <Route path="/client/earnings">
                <ProtectedRoute userType="client" component={SalonEarnings} />
              </Route>
              <Route path="/client/reviews">
                <ProtectedRoute userType="client" component={SalonReviews} />
              </Route>
              <Route path="/client/profile">
                <ProtectedRoute userType="client" component={SalonOwnerProfile} />
              </Route>

              {/* Legacy Salon Routes (for backward compatibility) */}
              <Route path="/salon">
                <ProtectedRoute userType="client" component={SalonDashboard} />
              </Route>
              <Route path="/salon/bookings">
                <ProtectedRoute userType="client" component={SalonBookings} />
              </Route>
              <Route path="/salon/services">
                <ProtectedRoute userType="client" component={SalonServices} />
              </Route>
              <Route path="/salon/staff">
                <ProtectedRoute userType="client" component={SalonStaff} />
              </Route>
              <Route path="/salon/earnings">
                <ProtectedRoute userType="client" component={SalonEarnings} />
              </Route>
              <Route path="/salon/reviews">
                <ProtectedRoute userType="client" component={SalonReviews} />
              </Route>
              <Route path="/salon/profile">
                <ProtectedRoute userType="client" component={SalonOwnerProfile} />
              </Route>

              {/* Fallback to 404 */}
              <Route component={NotFound} />
            </Switch>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
