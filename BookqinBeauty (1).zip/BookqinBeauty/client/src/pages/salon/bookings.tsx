import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar, Clock, Phone, MapPin, User, Check, X, Filter, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { formatDate, formatTime, getInitials } from "@/lib/utils";
import { BOOKING_STATUS_CONFIG } from "@/lib/constants";
import { Booking, BookingStatus } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function SalonBookings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<BookingStatus>("pending");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [newStatus, setNewStatus] = useState<BookingStatus>("confirmed");

  // Fetch bookings
  const { data: bookingsData, isLoading } = useQuery({
    queryKey: ['/api/salon/bookings'],
  });

  // Update booking status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: BookingStatus }) => {
      return await apiRequest("PATCH", `/api/salon/bookings/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/salon/bookings'] });
      setShowStatusDialog(false);
      
      toast({
        title: "Booking status updated",
        description: `The booking has been ${newStatus}.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bookings: Booking[] = bookingsData?.bookings || [];
  
  const filteredBookings = bookings
    .filter(booking => booking.status === activeTab)
    .filter(booking => {
      if (!searchTerm) return true;
      // Search by booking ID, customer name, or service
      return (
        booking.bookingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (booking.customerName && booking.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (booking.serviceName && booking.serviceName.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    });

  const handleUpdateStatus = () => {
    if (selectedBooking && newStatus) {
      updateStatusMutation.mutate({ id: selectedBooking.id, status: newStatus });
    }
  };

  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-playfair font-semibold">Bookings Management</h1>
        <p className="text-gray-600 dark:text-gray-300">View and manage all your appointments</p>
      </div>

      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Search by booking ID, customer name..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <span>Filters</span>
            </Button>
            <Button className="bg-bronze hover:bg-bronze-dark text-white">
              <span>Export</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as BookingStatus)}>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 mb-6">
          <TabsList className="grid grid-cols-4 mb-6">
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="confirmed">Confirmed</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
          </TabsList>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-center py-12">
            <div className="spinner"></div>
          </div>
        )}

        {/* Common content for all tabs */}
        {!isLoading && (
          <div className="space-y-4">
            {filteredBookings.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mb-4">
                  <Calendar className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium dark:text-white">No {activeTab} Bookings</h3>
                <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                  There are no bookings with {activeTab} status at the moment.
                </p>
              </div>
            ) : (
              filteredBookings.map((booking) => (
                <BookingCard 
                  key={booking.id} 
                  booking={booking} 
                  onViewDetails={() => {
                    setSelectedBooking(booking);
                    setShowDetailsDialog(true);
                  }}
                  onUpdateStatus={() => {
                    setSelectedBooking(booking);
                    setNewStatus(booking.status === "pending" ? "confirmed" : "completed");
                    setShowStatusDialog(true);
                  }}
                />
              ))
            )}
          </div>
        )}
      </Tabs>

      {/* Booking Details Dialog */}
      {selectedBooking && (
        <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Booking Details</DialogTitle>
              <DialogDescription>
                Booking ID: #{selectedBooking.bookingId}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src={selectedBooking.customerImage} />
                  <AvatarFallback>{getInitials(selectedBooking.customerName || "")}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium dark:text-white">{selectedBooking.customerName || "Customer"}</h4>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                    <Phone className="h-3.5 w-3.5 mr-1" />
                    <span>{selectedBooking.customerPhone || "Not available"}</span>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Date & Time</p>
                  <p className="font-medium dark:text-white">
                    {formatDate(selectedBooking.date)} at {formatTime(selectedBooking.time)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Status</p>
                  <Badge className={BOOKING_STATUS_CONFIG[selectedBooking.status].color}>
                    {BOOKING_STATUS_CONFIG[selectedBooking.status].label}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Service</p>
                  <p className="font-medium dark:text-white">{selectedBooking.serviceName || "Service"}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Staff</p>
                  <p className="font-medium dark:text-white">{selectedBooking.staffName || "Not assigned"}</p>
                </div>
              </div>
              
              {selectedBooking.notes && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Customer Notes</p>
                    <p className="font-medium dark:text-white">{selectedBooking.notes}</p>
                  </div>
                </>
              )}
            </div>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setShowDetailsDialog(false)}
              >
                Close
              </Button>
              
              {selectedBooking.status === "pending" && (
                <Button 
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => {
                    setShowDetailsDialog(false);
                    setNewStatus("confirmed");
                    setShowStatusDialog(true);
                  }}
                >
                  <Check className="h-4 w-4 mr-2" />
                  Confirm
                </Button>
              )}
              
              {selectedBooking.status === "confirmed" && (
                <Button 
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => {
                    setShowDetailsDialog(false);
                    setNewStatus("completed");
                    setShowStatusDialog(true);
                  }}
                >
                  <Check className="h-4 w-4 mr-2" />
                  Mark as Completed
                </Button>
              )}
              
              {(selectedBooking.status === "pending" || selectedBooking.status === "confirmed") && (
                <Button 
                  variant="destructive" 
                  className="flex-1"
                  onClick={() => {
                    setShowDetailsDialog(false);
                    setNewStatus("cancelled");
                    setShowStatusDialog(true);
                  }}
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Status Update Confirmation Dialog */}
      {selectedBooking && (
        <Dialog open={showStatusDialog} onOpenChange={setShowStatusDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Update Booking Status</DialogTitle>
              <DialogDescription>
                Are you sure you want to {newStatus === "cancelled" ? "cancel" : newStatus === "completed" ? "mark as completed" : "confirm"} this booking?
              </DialogDescription>
            </DialogHeader>
            
            <div>
              <p className="font-medium dark:text-white mb-2">Booking #{selectedBooking.bookingId}</p>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {selectedBooking.customerName} • {formatDate(selectedBooking.date)} at {formatTime(selectedBooking.time)}
              </p>
            </div>
            
            <DialogFooter className="flex flex-col sm:flex-row sm:space-x-2">
              <Button
                variant="outline"
                onClick={() => setShowStatusDialog(false)}
                className="mt-2 sm:mt-0"
                disabled={updateStatusMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdateStatus}
                className={
                  newStatus === "cancelled" 
                    ? "bg-red-600 hover:bg-red-700 text-white" 
                    : newStatus === "completed"
                    ? "bg-blue-600 hover:bg-blue-700 text-white"
                    : ""
                }
                disabled={updateStatusMutation.isPending}
              >
                {updateStatusMutation.isPending ? (
                  "Processing..."
                ) : (
                  <>
                    {newStatus === "cancelled" && "Cancel Booking"}
                    {newStatus === "confirmed" && "Confirm Booking"}
                    {newStatus === "completed" && "Complete Booking"}
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

interface BookingCardProps {
  booking: Booking;
  onViewDetails: () => void;
  onUpdateStatus: () => void;
}

function BookingCard({ booking, onViewDetails, onUpdateStatus }: BookingCardProps) {
  const statusConfig = BOOKING_STATUS_CONFIG[booking.status];

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="flex-grow">
            <div className="flex justify-between items-start md:items-center">
              <div>
                <Badge className={`${statusConfig.color} mb-2`}>
                  <i className={`${statusConfig.icon} mr-1`}></i>
                  {statusConfig.label}
                </Badge>
                <h3 className="font-medium text-lg dark:text-white">Booking #{booking.bookingId}</h3>
              </div>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mt-2">
              <Calendar className="h-4 w-4 mr-1" />
              <span>{formatDate(booking.date)}</span>
              <span className="mx-2">•</span>
              <Clock className="h-4 w-4 mr-1" />
              <span>{formatTime(booking.time)}</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center mt-2">
              <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                <User className="h-4 w-4 mr-1" />
                <span>{booking.customerName || "Customer"}</span>
              </div>
              <span className="hidden sm:block mx-2 text-gray-300 dark:text-gray-600">•</span>
              <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mt-1 sm:mt-0">
                <Phone className="h-4 w-4 mr-1" />
                <span>{booking.customerPhone || "Not available"}</span>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="outline" className="bg-gray-50 dark:bg-gray-800">
                {booking.serviceName || "Service"}
              </Badge>
              {booking.staffName && (
                <Badge variant="outline" className="bg-gray-50 dark:bg-gray-800">
                  Staff: {booking.staffName}
                </Badge>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2 mt-4 md:mt-0">
            <Button
              variant="outline"
              className="flex-1 md:flex-none"
              onClick={onViewDetails}
            >
              View Details
            </Button>
            
            {booking.status === "pending" && (
              <Button
                className="flex-1 md:flex-none bg-green-600 hover:bg-green-700 text-white"
                onClick={onUpdateStatus}
              >
                <Check className="h-4 w-4 mr-2" />
                Accept
              </Button>
            )}
            
            {booking.status === "confirmed" && (
              <Button
                className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-700 text-white"
                onClick={onUpdateStatus}
              >
                <Check className="h-4 w-4 mr-2" />
                Complete
              </Button>
            )}
            
            {(booking.status === "pending" || booking.status === "confirmed") && (
              <Button
                variant="destructive"
                className="flex-1 md:flex-none"
                onClick={onUpdateStatus}
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
