import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MapPin, Phone, Mail, Clock, Upload, Save, CheckCircle2, AlertCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/components/providers/AuthProvider";
import { Salon } from "@shared/schema";

// Profile form schema
const salonProfileSchema = z.object({
  name: z.string().min(1, "Salon name is required"),
  description: z.string().optional(),
  address: z.string().min(1, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  pincode: z.string().min(1, "Pincode is required"),
  contactNumber: z.string().min(10, "Contact number must be at least 10 digits"),
  email: z.string().email("Invalid email format").optional(),
  website: z.string().url("Invalid website URL").optional().or(z.literal("")),
  openingTime: z.string().optional(),
  closingTime: z.string().optional(),
  isHomeServiceAvailable: z.boolean().optional(),
  acceptsOnlineBooking: z.boolean().default(true),
});

type SalonProfileFormValues = z.infer<typeof salonProfileSchema>;

export default function SalonOwnerProfile() {
  const { toast } = useToast();
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState("general");
  
  // Fetch salon profile
  const { data: salonData, isLoading } = useQuery({
    queryKey: ['/api/salon/profile'],
  });
  
  // Update salon profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: SalonProfileFormValues) => {
      return await apiRequest("PUT", "/api/salon/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/salon/profile'] });
      
      toast({
        title: "Profile updated",
        description: "Your salon profile has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update profile image mutation
  const updateImageMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      return await apiRequest("POST", "/api/salon/profile/image", formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/salon/profile'] });
      
      toast({
        title: "Image updated",
        description: "Your salon profile image has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update image",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const form = useForm<SalonProfileFormValues>({
    resolver: zodResolver(salonProfileSchema),
    defaultValues: {
      name: salonData?.name || "",
      description: salonData?.description || "",
      address: salonData?.address || "",
      city: salonData?.city || "",
      state: salonData?.state || "",
      pincode: salonData?.pincode || "",
      contactNumber: salonData?.contactNumber || "",
      email: salonData?.email || "",
      website: salonData?.website || "",
      openingTime: salonData?.openingTime || "",
      closingTime: salonData?.closingTime || "",
      isHomeServiceAvailable: salonData?.isHomeServiceAvailable || false,
      acceptsOnlineBooking: salonData?.acceptsOnlineBooking !== false,
    },
  });
  
  // Update form when salon data is fetched
  if (salonData && !form.formState.isDirty) {
    form.reset({
      name: salonData.name || "",
      description: salonData.description || "",
      address: salonData.address || "",
      city: salonData.city || "",
      state: salonData.state || "",
      pincode: salonData.pincode || "",
      contactNumber: salonData.contactNumber || "",
      email: salonData.email || "",
      website: salonData.website || "",
      openingTime: salonData.openingTime || "",
      closingTime: salonData.closingTime || "",
      isHomeServiceAvailable: salonData.isHomeServiceAvailable || false,
      acceptsOnlineBooking: salonData.acceptsOnlineBooking !== false,
    });
  }
  
  const onSubmit = (data: SalonProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };
  
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const formData = new FormData();
    formData.append('image', file);
    
    updateImageMutation.mutate(formData);
  };
  
  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-playfair font-semibold">Salon Profile</h1>
        <p className="text-gray-600 dark:text-gray-300">Manage your salon's information and settings</p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-3 md:grid-cols-3">
          <TabsTrigger value="general">General Information</TabsTrigger>
          <TabsTrigger value="hours">Business Hours</TabsTrigger>
          <TabsTrigger value="settings">Account Settings</TabsTrigger>
        </TabsList>
        
        {/* General Information Tab */}
        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Profile</CardTitle>
              <CardDescription>
                Update your salon's profile information visible to customers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-8">
                <div className="flex flex-col items-center">
                  <div className="relative">
                    <Avatar className="w-32 h-32">
                      <AvatarImage src={salonData?.profileImage || undefined} alt={salonData?.name || "Salon"} />
                      <AvatarFallback className="text-2xl">
                        {salonData?.name?.charAt(0) || "S"}
                      </AvatarFallback>
                    </Avatar>
                    <label htmlFor="profile-image" className="absolute -right-2 bottom-0 cursor-pointer">
                      <div className="bg-primary hover:bg-primary/90 text-white p-2 rounded-full">
                        <Upload className="h-4 w-4" />
                      </div>
                      <input 
                        id="profile-image" 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={handleImageUpload}
                        disabled={updateImageMutation.isPending}
                      />
                    </label>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                    Upload a high-quality logo or storefront image
                  </p>
                  
                  {salonData?.isVerified ? (
                    <div className="mt-4 flex items-center text-green-600 dark:text-green-400">
                      <CheckCircle2 className="h-4 w-4 mr-1" />
                      <span className="text-sm">Verified Business</span>
                    </div>
                  ) : (
                    <div className="mt-4 flex items-center text-amber-600 dark:text-amber-400">
                      <AlertCircle className="h-4 w-4 mr-1" />
                      <span className="text-sm">Verification Pending</span>
                    </div>
                  )}
                </div>
                
                <div className="flex-1">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Salon Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your salon's name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Describe your salon and services" 
                                className="resize-none" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              This will be displayed on your salon profile
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="contactNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Contact Number</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                  <Input className="pl-10" placeholder="e.g., 9876543210" {...field} />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Business Email</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                  <Input className="pl-10" placeholder="e.g., contact@yoursalon.com" {...field} />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Input className="pl-10" placeholder="Street address" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>City</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Mumbai" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="state"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>State</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Maharashtra" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="pincode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Pincode</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., 400001" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="mt-6 flex justify-end">
                        <Button 
                          type="submit" 
                          disabled={updateProfileMutation.isPending}
                          className="flex items-center gap-2"
                        >
                          <Save className="h-4 w-4" />
                          {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Business Hours Tab */}
        <TabsContent value="hours" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Business Hours</CardTitle>
              <CardDescription>
                Set your salon's operating hours
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="openingTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Opening Time</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Clock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input 
                                className="pl-10" 
                                type="time"
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="closingTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Closing Time</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Clock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input 
                                className="pl-10" 
                                type="time"
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* More detailed operating hours could be added here */}
                  
                  <div className="mt-6 flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      <Save className="h-4 w-4" />
                      {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Account Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Booking Settings</CardTitle>
              <CardDescription>
                Configure how customers can book appointments with you
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="acceptsOnlineBooking"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel>Accept Online Bookings</FormLabel>
                          <FormDescription>
                            Allow customers to book appointments online through the platform
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="isHomeServiceAvailable"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel>Offer Home Services</FormLabel>
                          <FormDescription>
                            Provide services at customer's location
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <div className="mt-6 flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                      className="flex items-center gap-2"
                    >
                      <Save className="h-4 w-4" />
                      {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}