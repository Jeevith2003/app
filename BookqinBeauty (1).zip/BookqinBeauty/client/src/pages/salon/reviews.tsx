import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Star, Search, MessageCircle, ThumbsUp } from "lucide-react";
import { formatDate, getInitials } from "@/lib/utils";
import { useAuth } from "@/components/providers/AuthProvider";
import { ReviewWithCustomer } from "@/lib/types";

export default function SalonReviews() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [replyText, setReplyText] = useState("");
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  
  // Fetch reviews
  const { data: reviewsData, isLoading } = useQuery({
    queryKey: ['/api/salon/reviews', activeTab],
  });
  
  const reviews: ReviewWithCustomer[] = reviewsData?.reviews || [];
  
  // Filter reviews based on search term and tab
  const filteredReviews = reviews.filter(review => {
    if (searchTerm && !(
      review.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.comment?.toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    switch (activeTab) {
      case "positive":
        return review.rating >= 4;
      case "neutral":
        return review.rating === 3;
      case "negative":
        return review.rating <= 2;
      default:
        return true;
    }
  });
  
  const handleReplySubmit = (reviewId: number) => {
    // Implement reply submission logic here
    console.log(`Reply to review ${reviewId}: ${replyText}`);
    setReplyText("");
    setReplyingTo(null);
  };
  
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300 dark:text-gray-600"
          }`}
        />
      ));
  };
  
  const getRatingStyle = (rating: number) => {
    if (rating >= 4) return "text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950";
    if (rating === 3) return "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950";
    return "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950";
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="spinner"></div>
      </div>
    );
  }
  
  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-playfair font-semibold">Customer Reviews</h1>
        <p className="text-gray-600 dark:text-gray-300">Manage and respond to customer feedback</p>
      </div>
      
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="col-span-1 md:col-span-3 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Search reviews by customer name or content..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="col-span-1">
              <TabsList className="w-full grid grid-cols-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="positive">Positive</TabsTrigger>
                <TabsTrigger value="neutral">Neutral</TabsTrigger>
                <TabsTrigger value="negative">Negative</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 gap-6">
        {filteredReviews.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mb-4">
              <MessageCircle className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium dark:text-white">No Reviews Found</h3>
            <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
              {searchTerm
                ? `No reviews matching "${searchTerm}"`
                : activeTab !== "all"
                  ? `You don't have any ${activeTab} reviews yet`
                  : "You haven't received any reviews yet. As customers visit your salon, their feedback will appear here."}
            </p>
          </div>
        ) : (
          filteredReviews.map((review) => (
            <Card key={review.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <Avatar>
                        <AvatarImage src={review.customerImage} />
                        <AvatarFallback>{getInitials(review.customerName || "Anonymous")}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium dark:text-white">{review.customerName || "Anonymous Customer"}</h3>
                        <div className="flex items-center mt-1 gap-2">
                          <div className="flex">{renderStars(review.rating)}</div>
                          <Badge className={`${getRatingStyle(review.rating)}`}>
                            {review.rating}/5
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                          {formatDate(review.createdAt?.toString() || new Date().toString())}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <p className="text-gray-800 dark:text-gray-200">
                      {review.comment || "No comment provided."}
                    </p>
                  </div>
                  
                  {review.reply && (
                    <div className="mt-4 bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                      <div className="flex items-start gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="text-xs">{getInitials(profile?.name || "Salon")}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center">
                            <h4 className="text-sm font-medium dark:text-white">Your Reply</h4>
                            <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">
                              {formatDate(review.replyDate?.toString() || new Date().toString())}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                            {review.reply}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {!review.reply && (
                    <div className="mt-4">
                      {replyingTo === review.id ? (
                        <div className="space-y-3">
                          <textarea
                            className="w-full px-3 py-2 text-sm border rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                            rows={3}
                            placeholder="Type your reply here..."
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                          />
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setReplyingTo(null);
                                setReplyText("");
                              }}
                            >
                              Cancel
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleReplySubmit(review.id)}
                              disabled={!replyText.trim()}
                            >
                              Send Reply
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-2"
                          onClick={() => setReplyingTo(review.id)}
                        >
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Reply to Review
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </>
  );
}