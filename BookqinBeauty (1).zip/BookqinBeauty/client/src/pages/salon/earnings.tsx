import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from "recharts";
import { 
  DollarSign, 
  TrendingUp, 
  Download, 
  Calendar, 
  FileText, 
  ArrowUpRight 
} from "lucide-react";
import { formatPrice } from "@/lib/utils";

// Sample data for charts
const monthlyRevenueData = [
  { name: "Jan", revenue: 380000 },
  { name: "Feb", revenue: 420000 },
  { name: "Mar", revenue: 480000 },
  { name: "Apr", revenue: 520000 },
  { name: "May", revenue: 490000 },
  { name: "Jun", revenue: 560000 },
  { name: "Jul", revenue: 600000 },
  { name: "Aug", revenue: 650000 },
  { name: "Sep", revenue: 720000 },
  { name: "Oct", revenue: 780000 },
  { name: "Nov", revenue: 820000 },
  { name: "Dec", revenue: 900000 },
];

const serviceRevenueData = [
  { name: "Haircut", value: 40 },
  { name: "Coloring", value: 25 },
  { name: "Styling", value: 15 },
  { name: "Spa", value: 10 },
  { name: "Makeup", value: 10 },
];

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

const recentTransactions = [
  {
    id: 1,
    customer: "Meera Desai",
    service: "Haircut & Styling",
    amount: 80000,
    date: "2023-11-25",
    status: "completed"
  },
  {
    id: 2,
    customer: "Raj Kumar",
    service: "Hair Coloring",
    amount: 250000,
    date: "2023-11-24",
    status: "completed"
  },
  {
    id: 3,
    customer: "Priya Sharma",
    service: "Spa Therapy",
    amount: 150000,
    date: "2023-11-24",
    status: "completed"
  },
  {
    id: 4,
    customer: "Arjun Mehta",
    service: "Men's Grooming",
    amount: 60000,
    date: "2023-11-23",
    status: "completed"
  }
];

export default function SalonEarnings() {
  const [selectedPeriod, setSelectedPeriod] = useState("yearly");
  const [activeTab, setActiveTab] = useState("overview");
  
  // Fetch earnings data
  const { data: earningsData, isLoading } = useQuery({
    queryKey: ['/api/salon/earnings', selectedPeriod],
  });
  
  const stats = earningsData?.stats || {
    totalRevenue: 6500000, // ₹65,000
    totalBookings: 520,
    averageBookingValue: 125000, // ₹1,250
    topService: "Haircut & Styling",
    growth: 12.5, // percentage
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <span className="loading loading-spinner"></span>
      </div>
    );
  }
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-playfair font-semibold">Earnings & Reports</h1>
          <p className="text-gray-600 dark:text-gray-300">Track your salon's financial performance</p>
        </div>
        <div className="flex items-center space-x-3">
          <Select
            value={selectedPeriod}
            onValueChange={setSelectedPeriod}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline-block">Export</span>
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">Total Revenue</p>
                <h3 className="text-2xl font-semibold mt-1 dark:text-white">{formatPrice(stats.totalRevenue)}</h3>
                <div className="mt-1 flex items-center text-green-600 dark:text-green-400 text-sm">
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                  <span>+{stats.growth}% from previous {selectedPeriod.slice(0, -2)}</span>
                </div>
              </div>
              <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-lg">
                <DollarSign className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">Total Bookings</p>
                <h3 className="text-2xl font-semibold mt-1 dark:text-white">{stats.totalBookings}</h3>
                <div className="mt-1 flex items-center text-gray-600 dark:text-gray-400 text-sm">
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>This {selectedPeriod.slice(0, -2)}</span>
                </div>
              </div>
              <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg">
                <Calendar className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">Average Booking Value</p>
                <h3 className="text-2xl font-semibold mt-1 dark:text-white">{formatPrice(stats.averageBookingValue)}</h3>
                <div className="mt-1 flex items-center text-gray-600 dark:text-gray-400 text-sm">
                  <FileText className="h-3 w-3 mr-1" />
                  <span>Per transaction</span>
                </div>
              </div>
              <div className="bg-purple-100 dark:bg-purple-900/30 p-3 rounded-lg">
                <TrendingUp className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">Top Service</p>
                <h3 className="text-2xl font-semibold mt-1 dark:text-white" style={{ maxWidth: "180px", overflow: "hidden", textOverflow: "ellipsis" }}>{stats.topService}</h3>
                <div className="mt-1 flex items-center text-gray-600 dark:text-gray-400 text-sm">
                  <i className="ri-scissors-line mr-1 text-xs"></i>
                  <span>Most popular</span>
                </div>
              </div>
              <div className="bg-amber-100 dark:bg-amber-900/30 p-3 rounded-lg">
                <i className="ri-trophy-line text-xl text-amber-600 dark:text-amber-400"></i>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Revenue {selectedPeriod === 'yearly' ? 'by Month' : selectedPeriod === 'monthly' ? 'by Week' : 'by Day'}</CardTitle>
                <CardDescription>
                  {selectedPeriod === 'yearly' 
                    ? 'Revenue trends throughout the year' 
                    : selectedPeriod === 'monthly' 
                      ? 'Revenue trends for this month' 
                      : 'Revenue trends for recent days'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={monthlyRevenueData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis tickFormatter={(value) => `₹${value / 100}`} />
                      <Tooltip 
                        formatter={(value) => [`₹${(value as number / 100).toFixed(2)}`, 'Revenue']}
                        contentStyle={{ backgroundColor: 'var(--background)', borderColor: 'var(--border)' }}
                      />
                      <Bar dataKey="revenue" fill="hsl(var(--chart-1))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Service</CardTitle>
                <CardDescription>
                  Breakdown of revenue by service category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={serviceRevenueData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {serviceRevenueData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value) => [`${value}%`, 'Revenue Share']}
                        contentStyle={{ backgroundColor: 'var(--background)', borderColor: 'var(--border)' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>
                Your most recent completed transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b dark:border-gray-700">
                      <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Customer</th>
                      <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Service</th>
                      <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Date</th>
                      <th className="py-3 px-4 text-right text-sm font-medium text-gray-600 dark:text-gray-300">Amount</th>
                      <th className="py-3 px-4 text-center text-sm font-medium text-gray-600 dark:text-gray-300">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentTransactions.map((transaction) => (
                      <tr key={transaction.id} className="border-b dark:border-gray-700">
                        <td className="py-3 px-4 dark:text-gray-200">{transaction.customer}</td>
                        <td className="py-3 px-4 dark:text-gray-200">{transaction.service}</td>
                        <td className="py-3 px-4 dark:text-gray-200">
                          {new Date(transaction.date).toLocaleDateString('en-US', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric'
                          })}
                        </td>
                        <td className="py-3 px-4 text-right font-medium dark:text-gray-200">{formatPrice(transaction.amount)}</td>
                        <td className="py-3 px-4">
                          <div className="flex justify-center">
                            <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                              {transaction.status}
                            </Badge>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4 flex justify-center">
                <Button variant="outline">View All Transactions</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Transactions Tab */}
        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>All Transactions</CardTitle>
              <CardDescription>
                Complete history of your salon's transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
                  <FileText className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium dark:text-white">Transaction History</h3>
                <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                  This section is currently being upgraded. Soon you'll be able to view and filter all transaction records with advanced options.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Financial Reports</CardTitle>
              <CardDescription>
                Generate and download detailed financial reports
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-6 border-b dark:border-gray-700">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium dark:text-white">Revenue Report</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            Detailed breakdown of all revenue streams
                          </p>
                        </div>
                        <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg">
                          <i className="ri-line-chart-line text-xl text-blue-600 dark:text-blue-400"></i>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Available Formats:</span>
                        <div className="flex space-x-2">
                          <Badge variant="outline">PDF</Badge>
                          <Badge variant="outline">Excel</Badge>
                          <Badge variant="outline">CSV</Badge>
                        </div>
                      </div>
                      <Button className="w-full">Generate Report</Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-6 border-b dark:border-gray-700">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium dark:text-white">Service Performance</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            Analytics on your service offerings
                          </p>
                        </div>
                        <div className="bg-purple-100 dark:bg-purple-900/30 p-3 rounded-lg">
                          <i className="ri-scissors-line text-xl text-purple-600 dark:text-purple-400"></i>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Available Formats:</span>
                        <div className="flex space-x-2">
                          <Badge variant="outline">PDF</Badge>
                          <Badge variant="outline">Excel</Badge>
                        </div>
                      </div>
                      <Button className="w-full">Generate Report</Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-6 border-b dark:border-gray-700">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium dark:text-white">Customer Analytics</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            Insights about your customer base
                          </p>
                        </div>
                        <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-lg">
                          <i className="ri-user-line text-xl text-green-600 dark:text-green-400"></i>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Available Formats:</span>
                        <div className="flex space-x-2">
                          <Badge variant="outline">PDF</Badge>
                          <Badge variant="outline">Excel</Badge>
                        </div>
                      </div>
                      <Button className="w-full">Generate Report</Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-6 border-b dark:border-gray-700">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium dark:text-white">Tax Statement</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            Tax reports for accounting purposes
                          </p>
                        </div>
                        <div className="bg-amber-100 dark:bg-amber-900/30 p-3 rounded-lg">
                          <i className="ri-file-text-line text-xl text-amber-600 dark:text-amber-400"></i>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-sm text-gray-600 dark:text-gray-300">Available Formats:</span>
                        <div className="flex space-x-2">
                          <Badge variant="outline">PDF</Badge>
                          <Badge variant="outline">Excel</Badge>
                        </div>
                      </div>
                      <Button className="w-full">Generate Report</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
