import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Search, Plus, Edit, Trash2, User, Phone, Upload, Star } from "lucide-react";
import { getInitials } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Staff type
interface Staff {
  id: number;
  name: string;
  role: string;
  bio?: string;
  imageUrl?: string;
  specialities?: string[];
  phoneNumber?: string;
  email?: string;
}

// Form schema for staff
const staffFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  role: z.string().min(1, "Role is required"),
  bio: z.string().optional(),
  phoneNumber: z.string().optional(),
  email: z.string().email("Invalid email address").optional(),
  specialities: z.string().optional(),
});

type StaffFormValues = z.infer<typeof staffFormSchema>;

export default function SalonStaff() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  
  // Fetch staff
  const { data: staffData, isLoading } = useQuery({
    queryKey: ['/api/salon/staff'],
  });
  
  // Create staff mutation
  const createStaffMutation = useMutation({
    mutationFn: async (data: StaffFormValues) => {
      const { specialities, ...staffData } = data;
      
      // Convert specialities string to array
      const specialitiesArray = specialities ? specialities.split(',').map(s => s.trim()) : [];
      
      return await apiRequest("POST", "/api/salon/staff", {
        ...staffData,
        specialities: specialitiesArray,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/salon/staff'] });
      setAddDialogOpen(false);
      
      toast({
        title: "Staff member added",
        description: "The staff member has been added successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add staff member",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update staff mutation
  const updateStaffMutation = useMutation({
    mutationFn: async ({ id, ...data }: StaffFormValues & { id: number }) => {
      const { specialities, ...staffData } = data;
      
      // Convert specialities string to array
      const specialitiesArray = specialities ? specialities.split(',').map(s => s.trim()) : [];
      
      return await apiRequest("PUT", `/api/salon/staff/${id}`, {
        ...staffData,
        specialities: specialitiesArray,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/salon/staff'] });
      setEditDialogOpen(false);
      
      toast({
        title: "Staff member updated",
        description: "The staff member has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update staff member",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete staff mutation
  const deleteStaffMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/salon/staff/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/salon/staff'] });
      setDeleteDialogOpen(false);
      
      toast({
        title: "Staff member deleted",
        description: "The staff member has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete staff member",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Add staff form
  const addForm = useForm<StaffFormValues>({
    resolver: zodResolver(staffFormSchema),
    defaultValues: {
      name: "",
      role: "",
      bio: "",
      phoneNumber: "",
      email: "",
      specialities: "",
    },
  });
  
  // Edit staff form
  const editForm = useForm<StaffFormValues & { id: number }>({
    resolver: zodResolver(staffFormSchema.extend({ id: z.number() })),
    defaultValues: {
      id: 0,
      name: "",
      role: "",
      bio: "",
      phoneNumber: "",
      email: "",
      specialities: "",
    },
  });
  
  const staff: Staff[] = staffData?.staff || [];
  
  // Filter staff based on search term
  const filteredStaff = staff.filter(s => {
    if (!searchTerm) return true;
    return s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           s.role.toLowerCase().includes(searchTerm.toLowerCase());
  });
  
  const handleAddSubmit = (data: StaffFormValues) => {
    createStaffMutation.mutate(data);
  };
  
  const handleEditSubmit = (data: StaffFormValues & { id: number }) => {
    updateStaffMutation.mutate(data);
  };
  
  const handleEditStaff = (staff: Staff) => {
    setSelectedStaff(staff);
    
    // Convert specialities array to comma-separated string
    const specialitiesString = staff.specialities ? staff.specialities.join(', ') : '';
    
    editForm.reset({
      id: staff.id,
      name: staff.name,
      role: staff.role,
      bio: staff.bio || "",
      phoneNumber: staff.phoneNumber || "",
      email: staff.email || "",
      specialities: specialitiesString,
    });
    
    setEditDialogOpen(true);
  };
  
  const handleDeleteStaff = (staff: Staff) => {
    setSelectedStaff(staff);
    setDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (selectedStaff) {
      deleteStaffMutation.mutate(selectedStaff.id);
    }
  };
  
  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-playfair font-semibold">Staff Management</h1>
        <p className="text-gray-600 dark:text-gray-300">Manage your salon staff and specialists</p>
      </div>
      
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Search staff members..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-bronze hover:bg-bronze-dark text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Staff Member
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Add Staff Member</DialogTitle>
                  <DialogDescription>
                    Add a new staff member to your salon.
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...addForm}>
                  <form onSubmit={addForm.handleSubmit(handleAddSubmit)} className="space-y-4">
                    <div className="flex justify-center mb-4">
                      <div className="relative">
                        <Avatar className="w-24 h-24">
                          <AvatarFallback>
                            <User className="h-12 w-12" />
                          </AvatarFallback>
                        </Avatar>
                        <Button
                          type="button"
                          variant="secondary"
                          size="icon"
                          className="absolute -right-2 bottom-0 rounded-full"
                        >
                          <Upload className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <FormField
                      control={addForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addForm.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Role</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Hair Stylist" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={addForm.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Input className="pl-10" placeholder="e.g., 9876543210" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={addForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="e.g., john@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={addForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Brief description or introduction..."
                              className="resize-none"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addForm.control}
                      name="specialities"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Specialities</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., haircut, coloring, styling" {...field} />
                          </FormControl>
                          <FormDescription>
                            Separate specialities with commas
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setAddDialogOpen(false)}
                        disabled={createStaffMutation.isPending}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit"
                        disabled={createStaffMutation.isPending}
                      >
                        {createStaffMutation.isPending ? "Adding..." : "Add Staff Member"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
      
      {/* Loading State */}
      {isLoading && (
        <div className="flex justify-center py-12">
          <div className="spinner"></div>
        </div>
      )}
      
      {/* Staff List */}
      {!isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {filteredStaff.length === 0 ? (
            <div className="col-span-full text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mb-4">
                <User className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium dark:text-white">No Staff Members Found</h3>
              <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                {searchTerm
                  ? `No staff members matching "${searchTerm}"`
                  : "You haven't added any staff members yet. Click \"Add Staff Member\" to get started."}
              </p>
            </div>
          ) : (
            filteredStaff.map((staffMember) => (
              <StaffCard
                key={staffMember.id}
                staff={staffMember}
                onEdit={() => handleEditStaff(staffMember)}
                onDelete={() => handleDeleteStaff(staffMember)}
              />
            ))
          )}
        </div>
      )}
      
      {/* Edit Staff Dialog */}
      {selectedStaff && (
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Staff Member</DialogTitle>
              <DialogDescription>
                Update the details of {selectedStaff.name}.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-4">
                <div className="flex justify-center mb-4">
                  <div className="relative">
                    <Avatar className="w-24 h-24">
                      <AvatarImage src={selectedStaff.imageUrl} alt={selectedStaff.name} />
                      <AvatarFallback>{getInitials(selectedStaff.name)}</AvatarFallback>
                    </Avatar>
                    <Button
                      type="button"
                      variant="secondary"
                      size="icon"
                      className="absolute -right-2 bottom-0 rounded-full"
                    >
                      <Upload className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input className="pl-10" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={editForm.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea 
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="specialities"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Specialities</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>
                        Separate specialities with commas
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setEditDialogOpen(false)}
                    disabled={updateStaffMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={updateStaffMutation.isPending}
                  >
                    {updateStaffMutation.isPending ? "Updating..." : "Save Changes"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Delete Confirmation Dialog */}
      {selectedStaff && (
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Delete Staff Member</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete this staff member? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            
            <div>
              <p className="font-medium dark:text-white mb-2">{selectedStaff.name}</p>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {selectedStaff.role} • {selectedStaff.email || "No email provided"}
              </p>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setDeleteDialogOpen(false)}
                disabled={deleteStaffMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                variant="destructive"
                onClick={confirmDelete}
                disabled={deleteStaffMutation.isPending}
              >
                {deleteStaffMutation.isPending ? "Deleting..." : "Delete Staff Member"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

interface StaffCardProps {
  staff: Staff;
  onEdit: () => void;
  onDelete: () => void;
}

function StaffCard({ staff, onEdit, onDelete }: StaffCardProps) {
  return (
    <Card>
      <CardHeader className="pt-6 px-6 pb-0 text-center">
        <div className="flex flex-col items-center">
          <Avatar className="w-24 h-24 mb-3">
            <AvatarImage src={staff.imageUrl} alt={staff.name} />
            <AvatarFallback>{getInitials(staff.name)}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-xl">{staff.name}</CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{staff.role}</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-4 px-6">
        {staff.bio && (
          <p className="text-sm text-gray-600 dark:text-gray-300 text-center mb-4">
            {staff.bio}
          </p>
        )}
        
        <div className="space-y-2">
          {staff.phoneNumber && (
            <div className="flex items-center text-sm">
              <Phone className="h-4 w-4 mr-2 text-gray-500" />
              <span className="dark:text-gray-300">{staff.phoneNumber}</span>
            </div>
          )}
          
          {staff.email && (
            <div className="flex items-center text-sm">
              <i className="ri-mail-line mr-2 text-gray-500"></i>
              <span className="dark:text-gray-300">{staff.email}</span>
            </div>
          )}
        </div>
        
        {staff.specialities && staff.specialities.length > 0 && (
          <>
            <Separator className="my-4" />
            
            <div>
              <p className="text-sm font-medium mb-2 dark:text-white">Specialities</p>
              <div className="flex flex-wrap gap-1">
                {staff.specialities.map((speciality, i) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {speciality}
                  </Badge>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
      
      <CardFooter className="p-6 pt-2">
        <div className="w-full grid grid-cols-2 gap-2">
          <Button variant="outline" className="w-full" onClick={onEdit}>
            <Edit className="h-4 w-4 mr-1" />
            Edit
          </Button>
          <Button variant="destructive" className="w-full" onClick={onDelete}>
            <Trash2 className="h-4 w-4 mr-1" />
            Delete
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
