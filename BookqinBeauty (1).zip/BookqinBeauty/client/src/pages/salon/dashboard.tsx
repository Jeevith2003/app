import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  Calendar, 
  ArrowUp, 
  DollarSign, 
  Users, 
  Star, 
  MoreHorizontal,
  Edit
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend
} from "recharts";
import { formatPrice } from "@/lib/utils";
import { BOOKING_STATUS_CONFIG } from "@/lib/constants";

// Sample data for charts
const weeklyRevenueData = [
  { name: "Mon", revenue: 45000 },
  { name: "Tue", revenue: 52000 },
  { name: "Wed", revenue: 49000 },
  { name: "Thu", revenue: 63000 },
  { name: "Fri", revenue: 75000 },
  { name: "Sat", revenue: 85000 },
  { name: "Sun", revenue: 52000 },
];

const monthlyBookingsData = [
  { name: "Week 1", bookings: 45, revenue: 360000 },
  { name: "Week 2", bookings: 52, revenue: 420000 },
  { name: "Week 3", bookings: 48, revenue: 380000 },
  { name: "Week 4", bookings: 61, revenue: 490000 },
];

export default function SalonDashboard() {
  // Fetch salon dashboard data
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ['/api/salon/dashboard'],
  });

  const stats = dashboardData?.stats || {
    todayBookings: 12,
    todayRevenue: 845000, // in paisa (₹8,450)
    totalCustomers: 487,
    rating: 4.8,
    totalReviews: 248,
    comparedToYesterday: {
      bookings: 3,
      revenue: 12 // percentage
    }
  };

  const todayAppointments = dashboardData?.appointments || [
    {
      id: 1,
      time: "10:00 AM",
      customer: {
        id: 101,
        name: "Aisha Patel",
        image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32"
      },
      service: "Haircut & Styling",
      staff: "Neha S.",
      status: "confirmed"
    },
    {
      id: 2,
      time: "11:30 AM",
      customer: {
        id: 102,
        name: "Raj Kumar",
        image: "https://images.unsplash.com/photo-1558898479-33c0057a5d12?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32"
      },
      service: "Beard Trim",
      staff: "Vikram T.",
      status: "pending"
    },
    {
      id: 3,
      time: "2:00 PM",
      customer: {
        id: 103,
        name: "Priya Sharma",
        image: "https://images.unsplash.com/photo-1586297135537-94bc9ba060aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32"
      },
      service: "Facial & Massage",
      staff: "Meena R.",
      status: "confirmed"
    }
  ];

  const recentReviews = dashboardData?.reviews || [
    {
      id: 1,
      customer: {
        id: 201,
        name: "Meera Desai",
        image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48"
      },
      rating: 5,
      comment: "Amazing service! Neha did a fantastic job with my hair. The ambiance of the salon is also very luxurious and calming. Will definitely be back!",
      service: "Haircut & Styling",
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
    },
    {
      id: 2,
      customer: {
        id: 202,
        name: "Arjun Mehta",
        image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48"
      },
      rating: 4,
      comment: "Great experience overall. The haircut was exactly what I wanted and the staff was very professional. Would recommend to friends!",
      service: "Men's Grooming",
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
    }
  ];

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <span className="loading loading-spinner"></span>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-playfair font-semibold">Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-300">Overview of your salon performance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300">Today's Bookings</p>
                <h3 className="text-3xl font-semibold mt-1 dark:text-white">{stats.todayBookings}</h3>
              </div>
              <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg">
                <Calendar className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-green-600 dark:text-green-400">
              <ArrowUp className="h-4 w-4" />
              <span className="text-sm ml-1">+{stats.comparedToYesterday.bookings} from yesterday</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300">Revenue (Today)</p>
                <h3 className="text-3xl font-semibold mt-1 dark:text-white">{formatPrice(stats.todayRevenue)}</h3>
              </div>
              <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-lg">
                <DollarSign className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-green-600 dark:text-green-400">
              <ArrowUp className="h-4 w-4" />
              <span className="text-sm ml-1">+{stats.comparedToYesterday.revenue}% from yesterday</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300">Total Customers</p>
                <h3 className="text-3xl font-semibold mt-1 dark:text-white">{stats.totalCustomers}</h3>
              </div>
              <div className="bg-purple-100 dark:bg-purple-900/30 p-3 rounded-lg">
                <Users className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-green-600 dark:text-green-400">
              <ArrowUp className="h-4 w-4" />
              <span className="text-sm ml-1">+5 new customers</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 dark:text-gray-300">Rating</p>
                <h3 className="text-3xl font-semibold mt-1 dark:text-white">{stats.rating}</h3>
              </div>
              <div className="bg-yellow-100 dark:bg-yellow-900/30 p-3 rounded-lg">
                <Star className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-gray-600 dark:text-gray-400">
              <span className="text-sm">{stats.totalReviews} reviews total</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 dark:text-white">Weekly Revenue</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={weeklyRevenueData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis tickFormatter={(value) => `₹${value / 100}`} />
                  <Tooltip 
                    formatter={(value) => [`₹${(value as number / 100).toFixed(2)}`, 'Revenue']}
                    contentStyle={{ backgroundColor: 'var(--background)', borderColor: 'var(--border)' }}
                  />
                  <Bar dataKey="revenue" fill="hsl(var(--chart-1))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 dark:text-white">Monthly Overview</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={monthlyBookingsData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" />
                  <YAxis 
                    yAxisId="right" 
                    orientation="right" 
                    tickFormatter={(value) => `₹${value / 100}`}
                  />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === 'revenue') return [`₹${(value as number / 100).toFixed(2)}`, 'Revenue'];
                      return [value, 'Bookings'];
                    }}
                    contentStyle={{ backgroundColor: 'var(--background)', borderColor: 'var(--border)' }}
                  />
                  <Legend />
                  <Line 
                    yAxisId="left" 
                    type="monotone" 
                    dataKey="bookings" 
                    stroke="hsl(var(--chart-1))" 
                    activeDot={{ r: 8 }}
                  />
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="hsl(var(--chart-2))" 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Appointments */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold dark:text-white">Today's Appointments</h3>
            <Button variant="outline" className="text-navy hover:text-navy-light dark:text-navy-light dark:hover:text-white">
              View All
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b dark:border-gray-700">
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Time</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Customer</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Service</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Staff</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Status</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600 dark:text-gray-300">Action</th>
                </tr>
              </thead>
              <tbody>
                {todayAppointments.map((appointment) => {
                  const statusConfig = BOOKING_STATUS_CONFIG[appointment.status as keyof typeof BOOKING_STATUS_CONFIG];
                  return (
                    <tr key={appointment.id} className="border-b dark:border-gray-700">
                      <td className="py-3 px-4 dark:text-gray-200">{appointment.time}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center">
                          <Avatar className="w-8 h-8 rounded-full mr-2">
                            <AvatarImage src={appointment.customer.image} alt={appointment.customer.name} />
                            <AvatarFallback>{appointment.customer.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="dark:text-gray-200">{appointment.customer.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 dark:text-gray-200">{appointment.service}</td>
                      <td className="py-3 px-4 dark:text-gray-200">{appointment.staff}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2 py-1 text-xs rounded-full ${statusConfig.color}`}>
                          <i className={`${statusConfig.icon} mr-1`}></i>
                          {statusConfig.label}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="icon" className="text-navy hover:text-navy-light dark:text-gray-300 dark:hover:text-white">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reviews */}
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold dark:text-white">Recent Reviews</h3>
            <Button variant="outline" className="text-navy hover:text-navy-light dark:text-navy-light dark:hover:text-white">
              View All
            </Button>
          </div>

          <div className="space-y-6">
            {recentReviews.map((review) => (
              <div key={review.id} className={review.id < recentReviews.length ? "border-b pb-4 dark:border-gray-700" : ""}>
                <div className="flex justify-between items-start">
                  <div className="flex items-start">
                    <Avatar className="w-10 h-10 rounded-full mr-3">
                      <AvatarImage src={review.customer.image} alt={review.customer.name} />
                      <AvatarFallback>{review.customer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium dark:text-white">{review.customer.name}</h4>
                      <div className="flex items-center mt-1">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i}
                              className={`h-4 w-4 ${i < review.rating ? "text-yellow-400 fill-current" : "text-gray-300 dark:text-gray-600"}`}
                            />
                          ))}
                        </div>
                        <span className="text-gray-600 dark:text-gray-300 text-sm ml-2">
                          {review.createdAt.toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-gray-500 dark:text-gray-400 text-sm">
                    {review.service}
                  </div>
                </div>
                <p className="mt-3 text-gray-600 dark:text-gray-300">{review.comment}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
