import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { LandingHero } from "@/components/ui/landing-hero";
import { ServiceCategories } from "@/components/ui/service-categories";
import { FeaturedSalons } from "@/components/ui/featured-salons";
import { AiStyleFeature } from "@/components/ui/ai-style-feature";
import { useAuth } from "@/components/providers/AuthProvider";
import CustomerLayout from "@/components/layout/CustomerLayout";

export default function CustomerHome() {
  const { user, isLoading } = useAuth();

  return (
    <CustomerLayout>
      <div className="min-h-screen">
        {/* Hero Section */}
        <LandingHero />
        
        {/* Service Categories */}
        <ServiceCategories />
        
        {/* Featured Salons */}
        <FeaturedSalons />
        
        {/* AI Style Feature */}
        <AiStyleFeature />
        
        {/* Testimonials Section */}
        <div className="py-16 bg-softWhite dark:bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-playfair font-semibold text-gray-900 dark:text-white">
                What Our <span className="text-bronze">Customers</span> Say
              </h2>
              <p className="mt-4 text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Real stories from people who found their perfect style with Bookqin
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Testimonial 1 */}
              <div className="testimonial-card">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                    <img 
                      src="https://randomuser.me/api/portraits/women/33.jpg" 
                      alt="Priya S." 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-medium dark:text-white">Priya S.</h4>
                    <div className="flex mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <i key={star} className="ri-star-fill text-yellow-400 text-sm"></i>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-300">
                  "The AI style recommendation was spot on! It suggested a haircut that perfectly matched my face shape. The salon I booked through the app was amazing too."
                </p>
              </div>
              
              {/* Testimonial 2 */}
              <div className="testimonial-card">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                    <img 
                      src="https://randomuser.me/api/portraits/men/54.jpg" 
                      alt="Aditya M." 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-medium dark:text-white">Aditya M.</h4>
                    <div className="flex mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <i key={star} className={`ri-star-fill ${star <= 4 ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'} text-sm`}></i>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-300">
                  "As someone who's always been unsure about what style works for me, this app was a game-changer. Easy booking process and great service recommendations."
                </p>
              </div>
              
              {/* Testimonial 3 */}
              <div className="testimonial-card">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                    <img 
                      src="https://randomuser.me/api/portraits/women/66.jpg" 
                      alt="Sarah K." 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-medium dark:text-white">Sarah K.</h4>
                    <div className="flex mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <i key={star} className="ri-star-fill text-yellow-400 text-sm"></i>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-300">
                  "I love being able to book all my beauty services in one place! The interface is super intuitive and the salons are top-notch. Will definitely recommend to friends."
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="py-16 bg-white dark:bg-gray-800">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-playfair font-semibold text-gray-900 dark:text-white">
                Ready to Discover Your <span className="text-bronze">Perfect Look</span>?
              </h2>
              <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
                Join thousands of satisfied customers and book your next beauty appointment with confidence.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg" className="bg-bronze hover:bg-bronze-dark text-white btn-hover-effect">
                  Find Salons Near Me
                </Button>
                <Button size="lg" variant="outline" className="border-bronze text-bronze hover:bg-bronze/10">
                  Try AI Style Match
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <footer className="py-12 bg-navy dark:bg-navy-dark text-white">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between">
              <div className="mb-8 md:mb-0">
                <h2 className="text-2xl font-playfair font-bold">Bookqin</h2>
                <p className="text-white/70 mt-2 max-w-xs">
                  Where Beauty Meets Precision, Tailored for You
                </p>
                <div className="flex mt-4 space-x-4">
                  <a href="#" className="text-white/70 hover:text-bronze">
                    <i className="ri-instagram-line text-xl"></i>
                  </a>
                  <a href="#" className="text-white/70 hover:text-bronze">
                    <i className="ri-facebook-circle-line text-xl"></i>
                  </a>
                  <a href="#" className="text-white/70 hover:text-bronze">
                    <i className="ri-twitter-x-line text-xl"></i>
                  </a>
                  <a href="#" className="text-white/70 hover:text-bronze">
                    <i className="ri-youtube-line text-xl"></i>
                  </a>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                <div>
                  <h3 className="text-lg font-medium mb-4">For Customers</h3>
                  <ul className="space-y-2">
                    <li><a href="#" className="text-white/70 hover:text-bronze">Find Salons</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Book Services</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Style Recommendations</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Gift Cards</a></li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">For Salon Owners</h3>
                  <ul className="space-y-2">
                    <li><a href="#" className="text-white/70 hover:text-bronze">Join as Partner</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Salon Dashboard</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Business Resources</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Success Stories</a></li>
                  </ul>
                </div>
                
                <div className="col-span-2 md:col-span-1">
                  <h3 className="text-lg font-medium mb-4">About Bookqin</h3>
                  <ul className="space-y-2">
                    <li><a href="#" className="text-white/70 hover:text-bronze">Our Story</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">How It Works</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Privacy Policy</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Terms of Service</a></li>
                    <li><a href="#" className="text-white/70 hover:text-bronze">Contact Us</a></li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="mt-12 pt-8 border-t border-white/10 text-center md:text-left">
              <p className="text-white/50 text-sm">
                © {new Date().getFullYear()} Bookqin. All rights reserved.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </CustomerLayout>
  );
}