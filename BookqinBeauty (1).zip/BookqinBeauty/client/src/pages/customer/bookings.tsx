import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, ChevronRight } from "lucide-react";
import { formatDate, formatTime } from "@/lib/utils";
import { Booking } from "@shared/schema";
import { BOOKING_STATUS_CONFIG } from "@/lib/constants";

export default function CustomerBookings() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("upcoming");
  
  // Fetch bookings
  const { data: bookingsData, isLoading } = useQuery({
    queryKey: ['/api/customer/bookings'],
  });
  
  const bookings: Booking[] = bookingsData?.bookings || [];
  
  // Filter bookings based on status
  const upcomingBookings = bookings.filter(
    (booking) => booking.status === "pending" || booking.status === "confirmed"
  );
  
  const completedBookings = bookings.filter(
    (booking) => booking.status === "completed"
  );
  
  const cancelledBookings = bookings.filter(
    (booking) => booking.status === "cancelled"
  );
  
  return (
    <>
      <h1 className="text-2xl font-playfair font-semibold mb-6">My Bookings</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6 border-b border-gray-200 w-full justify-start">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
        </TabsList>
        
        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-center items-center min-h-[60vh]">
            <span className="loading loading-spinner"></span>
          </div>
        )}
        
        {/* Upcoming Bookings */}
        <TabsContent value="upcoming">
          {!isLoading && upcomingBookings.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium dark:text-white">No Upcoming Bookings</h3>
              <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                You don't have any upcoming appointments. Book a service to get started.
              </p>
              <Button
                className="mt-4 bg-navy hover:bg-navy-dark text-white"
                onClick={() => navigate("/")}
              >
                Book Now
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingBookings.map((booking) => (
                <BookingCard key={booking.id} booking={booking} />
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Completed Bookings */}
        <TabsContent value="completed">
          {!isLoading && completedBookings.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium dark:text-white">No Completed Bookings</h3>
              <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                You don't have any completed appointments yet.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {completedBookings.map((booking) => (
                <BookingCard key={booking.id} booking={booking} />
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Cancelled Bookings */}
        <TabsContent value="cancelled">
          {!isLoading && cancelledBookings.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium dark:text-white">No Cancelled Bookings</h3>
              <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                You don't have any cancelled appointments.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {cancelledBookings.map((booking) => (
                <BookingCard key={booking.id} booking={booking} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}

function BookingCard({ booking }: { booking: Booking }) {
  const [, navigate] = useLocation();
  
  const statusConfig = BOOKING_STATUS_CONFIG[booking.status as keyof typeof BOOKING_STATUS_CONFIG];
  
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div>
            <div className="flex justify-between items-start md:items-center">
              <div>
                <Badge className={`${statusConfig.color} mb-2`}>
                  <i className={`${statusConfig.icon} mr-1`}></i>
                  {statusConfig.label}
                </Badge>
                <h3 className="font-medium text-lg dark:text-white">Booking #{booking.bookingId}</h3>
              </div>
              <div className="md:hidden">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate(`/booking-details/${booking.id}`)}
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mt-2">
              <Calendar className="h-4 w-4 mr-1" />
              <span>{formatDate(booking.date)}</span>
              <span className="mx-2">•</span>
              <Clock className="h-4 w-4 mr-1" />
              <span>{formatTime(booking.time)}</span>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mt-1">
              <MapPin className="h-4 w-4 mr-1" />
              <span>Glamour Studio</span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="outline">Haircut & Styling</Badge>
              <Badge variant="outline">₹800</Badge>
            </div>
          </div>
          <div className="hidden md:flex items-start">
            <Button
              variant="ghost"
              className="text-navy dark:text-navy-light hover:text-navy-dark"
              onClick={() => navigate(`/booking-details/${booking.id}`)}
            >
              View Details
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
