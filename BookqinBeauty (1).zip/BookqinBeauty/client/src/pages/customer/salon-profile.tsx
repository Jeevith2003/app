import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { MapPin, Clock, Star, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ServiceCard } from "@/components/ui/service-card";
import { BookingSuccess } from "@/components/ui/booking-success";
import { formatPrice } from "@/lib/utils";
import { Service, Salon } from "@shared/schema";

export default function SalonProfile({ salonId }: { salonId: string }) {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("services");
  const [showBookingSuccess, setShowBookingSuccess] = useState(false);

  // Fetch salon details
  const { data: salonData, isLoading: isSalonLoading } = useQuery({
    queryKey: [`/api/customer/salon/${salonId}`],
  });

  // Fetch salon services
  const { data: servicesData, isLoading: isServicesLoading } = useQuery({
    queryKey: [`/api/customer/salon/${salonId}/services`],
  });

  const salon: Salon | undefined = salonData?.salon;
  const services: Service[] = servicesData?.services || [];

  if (isSalonLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <span className="loading loading-spinner"></span>
      </div>
    );
  }

  return (
    <>
      {/* Back Button */}
      <Button 
        variant="ghost" 
        className="mb-4 pl-0"
        onClick={() => navigate("/")}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Search
      </Button>

      {/* Salon Header */}
      <div className="rounded-xl overflow-hidden shadow-md mb-6">
        <div className="relative">
          <img 
            src={salon?.coverImage || "https://images.unsplash.com/photo-1600948836101-f9ffda59d250?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300&q=80"} 
            alt={salon?.name || "Salon"} 
            className="w-full h-48 md:h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4">
          <div className="flex flex-col md:flex-row justify-between items-start">
            <div className="flex items-start">
              <img 
                src={salon?.profileImage || "https://images.unsplash.com/photo-1600948836101-f9ffda59d250?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80"} 
                alt={salon?.name || "Salon"} 
                className="w-16 h-16 rounded-full object-cover border-4 border-white dark:border-gray-800 -mt-10 mr-3"
              />
              <div>
                <div className="flex items-center">
                  <h1 className="text-2xl font-playfair font-semibold dark:text-white">
                    {salon?.name || "Salon Name"}
                  </h1>
                  {salon?.isVerified && (
                    <Badge className="ml-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      <i className="ri-verified-badge-fill mr-1"></i>
                      <span>Verified</span>
                    </Badge>
                  )}
                </div>
                <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mt-1">
                  <MapPin className="h-3.5 w-3.5 mr-1" />
                  <span>{salon?.address}, {salon?.city}</span>
                </div>
                <div className="flex items-center mt-2">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="ml-1">{salon?.rating.toFixed(1) || "4.8"}</span>
                  </div>
                  <span className="mx-2 text-gray-300 dark:text-gray-600">|</span>
                  <span className="text-sm text-gray-600 dark:text-gray-300">{salon?.totalReviews || "0"}+ reviews</span>
                </div>
              </div>
            </div>
            <Button className="mt-4 md:mt-0 bg-bronze hover:bg-bronze-dark text-white">
              Book Appointment
            </Button>
          </div>
        </div>
      </div>

      {/* Salon Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6 border-b border-gray-200 w-full justify-start">
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="gallery">Gallery</TabsTrigger>
        </TabsList>
        
        {/* Services Tab */}
        <TabsContent value="services">
          <div className="space-y-6">
            <h2 className="text-xl font-semibold">Available Services</h2>
            
            {isServicesLoading ? (
              <div className="flex justify-center p-8">
                <span className="loading loading-spinner"></span>
              </div>
            ) : services.length === 0 ? (
              <div className="text-center py-10 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-gray-500 dark:text-gray-400">No services available at this time.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {services.map((service) => (
                  <ServiceCard
                    key={service.id}
                    service={service}
                    onBook={() => navigate(`/booking/${salonId}/${service.id}`)}
                  />
                ))}
              </div>
            )}
          </div>
        </TabsContent>
        
        {/* About Tab */}
        <TabsContent value="about">
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold mb-3">About {salon?.name}</h2>
              <p className="text-gray-600 dark:text-gray-300">
                {salon?.description || "This salon hasn't added a description yet."}
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Working Hours</h3>
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 space-y-2">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span>9:00 AM - 8:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span>10:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span>Closed</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Location</h3>
              <div className="bg-gray-100 dark:bg-gray-800 h-64 rounded-lg flex items-center justify-center">
                <p className="text-gray-500 dark:text-gray-400">Map will be displayed here</p>
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* Reviews Tab */}
        <TabsContent value="reviews">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Customer Reviews</h2>
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-current" />
                <span className="ml-1 font-semibold text-lg">{salon?.rating.toFixed(1) || "4.8"}</span>
                <span className="ml-2 text-gray-600 dark:text-gray-300">({salon?.totalReviews || "0"} reviews)</span>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="border-b pb-6">
                <div className="flex justify-between items-start">
                  <div className="flex items-start">
                    <img 
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48" 
                      className="w-10 h-10 rounded-full mr-3 object-cover" 
                      alt="Customer avatar" 
                    />
                    <div>
                      <h4 className="font-medium dark:text-white">Meera Desai</h4>
                      <div className="flex items-center mt-1">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star key={star} className="h-4 w-4 text-yellow-400 fill-current" />
                          ))}
                        </div>
                        <span className="text-gray-600 dark:text-gray-300 text-sm ml-2">1 day ago</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-gray-500 dark:text-gray-400 text-sm">
                    Haircut & Styling
                  </div>
                </div>
                <p className="mt-3 text-gray-600 dark:text-gray-300">
                  Amazing service! Neha did a fantastic job with my hair. The ambiance of the salon is also very luxurious and calming. Will definitely be back!
                </p>
              </div>
              
              <div>
                <div className="flex justify-between items-start">
                  <div className="flex items-start">
                    <img 
                      src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48" 
                      className="w-10 h-10 rounded-full mr-3 object-cover" 
                      alt="Customer avatar" 
                    />
                    <div>
                      <h4 className="font-medium dark:text-white">Arjun Mehta</h4>
                      <div className="flex items-center mt-1">
                        <div className="flex">
                          {[1, 2, 3, 4].map((star) => (
                            <Star key={star} className="h-4 w-4 text-yellow-400 fill-current" />
                          ))}
                          <Star className="h-4 w-4 text-gray-300" />
                        </div>
                        <span className="text-gray-600 dark:text-gray-300 text-sm ml-2">3 days ago</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-gray-500 dark:text-gray-400 text-sm">
                    Men's Grooming
                  </div>
                </div>
                <p className="mt-3 text-gray-600 dark:text-gray-300">
                  Great experience overall. The haircut was exactly what I wanted and the staff was very professional. Would recommend to friends!
                </p>
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* Gallery Tab */}
        <TabsContent value="gallery">
          <div className="space-y-6">
            <h2 className="text-xl font-semibold">Salon Gallery</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <img 
                src="https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80" 
                alt="Salon interior 1" 
                className="w-full h-40 object-cover rounded-lg"
              />
              <img 
                src="https://images.unsplash.com/photo-1562322140-8baeececf3df?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80" 
                alt="Salon interior 2" 
                className="w-full h-40 object-cover rounded-lg"
              />
              <img 
                src="https://images.unsplash.com/photo-1470259078422-826894b933aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80" 
                alt="Salon interior 3" 
                className="w-full h-40 object-cover rounded-lg"
              />
              <img 
                src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300&q=80" 
                alt="Salon interior 4" 
                className="w-full h-40 object-cover rounded-lg"
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Booking Success Modal */}
      {showBookingSuccess && (
        <BookingSuccess
          bookingId="BK12345"
          serviceName="Haircut & Styling"
          salonName={salon?.name || "Salon"}
          date="2023-12-15"
          time="14:00"
          onClose={() => setShowBookingSuccess(false)}
        />
      )}
    </>
  );
}
