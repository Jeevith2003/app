import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { ArrowLeft, Calendar, Clock, Info, ChevronRight, User, MapPin, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { BookingSuccess } from "@/components/ui/booking-success";
import { useAuth } from "@/components/providers/AuthProvider";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatPrice } from "@/lib/utils";
import { Service, Salon, insertBookingSchema } from "@shared/schema";
import { TIME_SLOTS } from "@/lib/constants";

// Create a booking form schema
const bookingFormSchema = z.object({
  date: z.string().min(1, "Please select a date"),
  time: z.string().min(1, "Please select a time"),
  serviceType: z.enum(["salon", "home"]),
  staffId: z.number().optional(),
  notes: z.string().optional(),
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

export default function Booking({ salonId, serviceId }: { salonId: string, serviceId: string }) {
  const [, navigate] = useLocation();
  const { profile } = useAuth();
  const [showBookingSuccess, setShowBookingSuccess] = useState(false);
  const [bookedId, setBookedId] = useState("");
  
  // Get today's date in format YYYY-MM-DD
  const today = new Date().toISOString().split('T')[0];

  // Fetch salon details
  const { data: salonData } = useQuery({
    queryKey: [`/api/customer/salon/${salonId}`],
  });

  // Fetch service details
  const { data: serviceData } = useQuery({
    queryKey: [`/api/customer/service/${serviceId}`],
  });

  const salon: Salon | undefined = salonData?.salon;
  const service: Service | undefined = serviceData?.service;

  // Create booking form
  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      date: today,
      time: "",
      serviceType: "salon",
      staffId: undefined,
      notes: "",
    },
  });

  // Calculate total
  const totalAmount = service ? service.price : 0;

  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormValues) => {
      const bookingData = {
        salonId: parseInt(salonId),
        serviceId: parseInt(serviceId),
        staffId: data.staffId,
        date: data.date,
        time: data.time,
        totalAmount,
        notes: data.notes,
      };
      
      const res = await apiRequest("POST", "/api/customer/bookings", bookingData);
      return res.json();
    },
    onSuccess: (data) => {
      setBookedId(data.booking.bookingId);
      setShowBookingSuccess(true);
      queryClient.invalidateQueries({ queryKey: ['/api/customer/bookings'] });
    },
  });

  const onSubmit = (data: BookingFormValues) => {
    createBookingMutation.mutate(data);
  };

  if (!service || !salon) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <span className="loading loading-spinner"></span>
      </div>
    );
  }

  return (
    <>
      {/* Back Button */}
      <Button 
        variant="ghost" 
        className="mb-4 pl-0"
        onClick={() => navigate(`/salon/${salonId}`)}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Salon
      </Button>

      <h1 className="text-2xl font-playfair font-semibold mb-6">Book Appointment</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Booking Form */}
        <div className="md:col-span-2">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Service Type Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Select Service Type</CardTitle>
                  <CardDescription>Choose where you want to receive the service</CardDescription>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="serviceType"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-3"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="salon" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              In-Salon Service
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="home" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Home Service (Additional charges may apply)
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Date & Time Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Select Date & Time</CardTitle>
                  <CardDescription>Choose your preferred appointment slot</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date</FormLabel>
                        <FormControl>
                          <div className="flex">
                            <Calendar className="h-4 w-4 mr-2 mt-3" />
                            <Input type="date" min={today} {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Time</FormLabel>
                        <FormControl>
                          <div className="grid grid-cols-4 gap-2">
                            {TIME_SLOTS.map((time) => (
                              <Button
                                key={time}
                                type="button"
                                variant={field.value === time ? "default" : "outline"}
                                className={`flex items-center justify-center ${
                                  field.value === time ? "bg-navy text-white" : ""
                                }`}
                                onClick={() => form.setValue("time", time)}
                              >
                                <Clock className="h-3 w-3 mr-1" />
                                {time}
                              </Button>
                            ))}
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Additional Notes */}
              <Card>
                <CardHeader>
                  <CardTitle>Additional Notes</CardTitle>
                  <CardDescription>Any special requests or information for the salon</CardDescription>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea 
                            placeholder="E.g., specific styling preferences, health conditions, etc."
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-navy hover:bg-navy-dark text-white"
                disabled={createBookingMutation.isPending}
              >
                {createBookingMutation.isPending ? "Processing..." : "Confirm Booking"}
              </Button>
            </form>
          </Form>
        </div>

        {/* Order Summary */}
        <div>
          <Card className="sticky top-6">
            <CardHeader>
              <CardTitle>Booking Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Service Details */}
              <div className="border-b pb-4">
                <div className="flex">
                  <img
                    src={service.imageUrl || "https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80"}
                    alt={service.name}
                    className="w-16 h-16 rounded-md object-cover mr-3"
                  />
                  <div>
                    <h4 className="font-medium dark:text-white">{service.name}</h4>
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      <span>{service.duration} mins</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Salon Info */}
              <div className="border-b pb-4 space-y-3">
                <div className="flex items-start">
                  <MapPin className="h-4 w-4 mr-2 mt-0.5 text-gray-500" />
                  <div>
                    <p className="font-medium dark:text-white">{salon.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {salon.address}, {salon.city}
                    </p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Star className="h-4 w-4 mr-2 text-yellow-400 fill-current" />
                  <span className="text-sm">{salon.rating.toFixed(1)} ({salon.totalReviews}+ reviews)</span>
                </div>
              </div>

              {/* Customer Info */}
              <div className="border-b pb-4">
                <div className="flex items-start">
                  <User className="h-4 w-4 mr-2 mt-0.5 text-gray-500" />
                  <div>
                    <p className="font-medium dark:text-white">Customer Details</p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {profile?.firstName} {profile?.lastName}
                    </p>
                  </div>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-300">Service Price</span>
                  <span>{formatPrice(service.price)}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span className="text-bronze dark:text-bronze-light">{formatPrice(totalAmount)}</span>
                </div>
              </div>

              {/* Info Note */}
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-md text-sm flex">
                <Info className="h-4 w-4 mr-2 mt-0.5 text-blue-500 dark:text-blue-400" />
                <p className="text-blue-700 dark:text-blue-300">
                  Payment will be collected at the salon. You can cancel up to 2 hours before your appointment.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Booking Success Modal */}
      {showBookingSuccess && (
        <BookingSuccess
          bookingId={bookedId}
          serviceName={service.name}
          salonName={salon.name}
          date={form.getValues().date}
          time={form.getValues().time}
          onClose={() => {
            setShowBookingSuccess(false);
            navigate("/bookings");
          }}
        />
      )}
    </>
  );
}
