import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useAuth } from "@/components/providers/AuthProvider";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader, LogOut, Camera, User, Settings, Bell, Star, Gift, ShieldCheck } from "lucide-react";
import { getInitials } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Profile update schema
const profileFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z.string().min(10, "Phone number must be at least 10 digits"),
  gender: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

export default function CustomerProfile() {
  const [, navigate] = useLocation();
  const { user, profile, logout } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  const [isGenderNeutral, setIsGenderNeutral] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      firstName: profile?.firstName || "",
      lastName: profile?.lastName || "",
      email: user?.email || "",
      phoneNumber: user?.phoneNumber || "",
      gender: profile?.gender || "",
    },
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      return await apiRequest("PUT", "/api/customer/profile", data);
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };
  
  const handleLogout = async () => {
    setIsLoading(true);
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      toast({
        title: "Failed to logout",
        description: "An error occurred while logging out.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <>
      <h1 className="text-2xl font-playfair font-semibold mb-6">My Profile</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Profile Sidebar */}
        <div className="md:col-span-1">
          <Card>
            <CardContent className="p-6 text-center space-y-4">
              <div className="relative inline-block">
                <Avatar className="w-24 h-24 mx-auto">
                  <AvatarImage src={profile?.profileImage} />
                  <AvatarFallback className="text-xl font-semibold">
                    {getInitials(`${profile?.firstName} ${profile?.lastName}`)}
                  </AvatarFallback>
                </Avatar>
                <Button variant="secondary" size="icon" className="absolute -right-2 bottom-0 rounded-full bg-bronze text-white hover:bg-bronze-dark">
                  <Camera className="h-4 w-4" />
                </Button>
              </div>
              <div>
                <h2 className="text-lg font-semibold dark:text-white">
                  {profile?.firstName} {profile?.lastName}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  @{user?.username}
                </p>
              </div>
              <div className="flex justify-center space-x-2">
                <Badge className="bg-navy">
                  <Star className="h-3 w-3 mr-1 fill-current" />
                  Loyal Customer
                </Badge>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-800 rounded-md p-3 text-left">
                <p className="text-sm text-gray-600 dark:text-gray-300">Wallet Balance</p>
                <p className="text-lg font-semibold text-navy dark:text-white">₹{(profile?.walletBalance || 0) / 100}</p>
              </div>
              
              <div className="pt-4">
                <Button
                  variant="outline"
                  className="w-full flex items-center text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
                  onClick={handleLogout}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Loader className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <LogOut className="h-4 w-4 mr-2" />
                  )}
                  Logout
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Profile Content */}
        <div className="md:col-span-3">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6 border-b border-gray-200 w-full justify-start">
              <TabsTrigger value="profile">
                <User className="h-4 w-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="preferences">
                <Settings className="h-4 w-4 mr-2" />
                Preferences
              </TabsTrigger>
              <TabsTrigger value="notifications">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="referrals">
                <Gift className="h-4 w-4 mr-2" />
                Referrals
              </TabsTrigger>
            </TabsList>
            
            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Name</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Last Name</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gender</FormLabel>
                            <FormControl>
                              <select
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-navy dark:focus:ring-navy-light bg-transparent"
                                {...field}
                              >
                                <option value="">Select gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                                <option value="prefer_not_to_say">Prefer not to say</option>
                              </select>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={updateProfileMutation.isPending}
                      >
                        {updateProfileMutation.isPending ? "Updating..." : "Save Changes"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Preferences Tab */}
            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Preferences</CardTitle>
                  <CardDescription>Manage your app preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <h4 className="font-medium dark:text-white">Gender Neutral Search</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        Show services regardless of gender categories
                      </p>
                    </div>
                    <Switch
                      checked={isGenderNeutral}
                      onCheckedChange={setIsGenderNeutral}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <h4 className="font-medium dark:text-white">Email Notifications</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        Receive booking confirmations and updates via email
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <h4 className="font-medium dark:text-white">SMS Notifications</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        Receive booking confirmations and updates via SMS
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <h4 className="font-medium dark:text-white">Marketing Communications</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        Receive offers, promotions, and newsletters
                      </p>
                    </div>
                    <Switch />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Save Preferences</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>Manage your notification preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <Bell className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium dark:text-white">Notification Center</h3>
                    <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
                      This section is currently under development. You'll soon be able to manage all your notification preferences from here.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Referrals Tab */}
            <TabsContent value="referrals">
              <Card>
                <CardHeader>
                  <CardTitle>Refer & Earn</CardTitle>
                  <CardDescription>Invite friends and earn rewards</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-gradient-to-r from-navy to-navy-light text-white rounded-lg p-6 mb-6">
                    <div className="flex flex-col md:flex-row items-center md:justify-between">
                      <div className="mb-4 md:mb-0">
                        <h3 className="text-xl font-semibold mb-2">Refer a friend and get ₹200</h3>
                        <p className="text-white/80">Your friend also gets ₹200 on their first booking</p>
                      </div>
                      <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                        <Gift className="h-8 w-8" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-medium mb-2 dark:text-white">Your Referral Code</h4>
                      <div className="flex">
                        <Input 
                          value="BOOKQIN200"
                          readOnly
                          className="bg-gray-50 dark:bg-gray-800"
                        />
                        <Button className="ml-2">Copy</Button>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2 dark:text-white">Share Link</h4>
                      <div className="flex">
                        <Input 
                          value="https://bookqin.com/refer/BOOKQIN200"
                          readOnly
                          className="bg-gray-50 dark:bg-gray-800"
                        />
                        <Button className="ml-2">Copy</Button>
                      </div>
                    </div>
                    
                    <div className="flex justify-center space-x-4">
                      <Button variant="outline" className="rounded-full w-12 h-12 p-0">
                        <i className="ri-whatsapp-line text-xl"></i>
                      </Button>
                      <Button variant="outline" className="rounded-full w-12 h-12 p-0">
                        <i className="ri-facebook-circle-line text-xl"></i>
                      </Button>
                      <Button variant="outline" className="rounded-full w-12 h-12 p-0">
                        <i className="ri-twitter-line text-xl"></i>
                      </Button>
                      <Button variant="outline" className="rounded-full w-12 h-12 p-0">
                        <i className="ri-instagram-line text-xl"></i>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
