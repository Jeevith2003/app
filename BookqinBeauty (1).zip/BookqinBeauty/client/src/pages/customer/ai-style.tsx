import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Camera, Upload, Image as ImageIcon, Star } from "lucide-react";
import { ServiceCard } from "@/components/ui/service-card";
import { SalonCard } from "@/components/ui/salon-card";

export default function AiStyle() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("upload");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleAnalyze = () => {
    setIsAnalyzing(true);
    // Simulate AI analysis
    setTimeout(() => {
      setIsAnalyzing(false);
      setShowResults(true);
    }, 2500);
  };
  
  return (
    <>
      {/* Back Button */}
      <Button 
        variant="ghost" 
        className="mb-4 pl-0"
        onClick={() => navigate("/")}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Home
      </Button>
      
      <h1 className="text-2xl font-playfair font-semibold mb-6">AI Style Recommendation</h1>
      
      {!showResults ? (
        <Card className="bg-white dark:bg-gray-800 shadow-soft">
          <CardHeader>
            <CardTitle className="text-center">Let AI Find Your Perfect Style</CardTitle>
            <CardDescription className="text-center">
              Upload your photo and our AI will recommend styles that suit your unique features
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="upload">Upload Photo</TabsTrigger>
                <TabsTrigger value="camera">Take Photo</TabsTrigger>
              </TabsList>
              
              <TabsContent value="upload" className="space-y-4">
                {uploadedImage ? (
                  <div className="relative">
                    <img 
                      src={uploadedImage} 
                      alt="Uploaded" 
                      className="w-full h-80 object-cover rounded-lg"
                    />
                    <Button 
                      variant="secondary" 
                      className="absolute top-2 right-2 bg-white/80 dark:bg-black/50"
                      onClick={() => setUploadedImage(null)}
                    >
                      Change
                    </Button>
                  </div>
                ) : (
                  <div 
                    className="bg-navy/5 dark:bg-navy/20 border-2 border-dashed border-navy/20 dark:border-navy/30 rounded-xl p-12 text-center"
                    onClick={() => document.getElementById("photo-upload")?.click()}
                  >
                    <Upload className="h-12 w-12 mx-auto text-navy/40 dark:text-navy/60 mb-4" />
                    <p className="text-navy/60 dark:text-navy/80 mb-2">Click to upload or drag and drop</p>
                    <p className="text-xs text-navy/40 dark:text-navy/60">JPG, PNG or HEIC up to 5MB</p>
                    
                    <input 
                      type="file" 
                      id="photo-upload" 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleFileUpload}
                    />
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="camera">
                <div className="bg-navy/5 dark:bg-navy/20 border-2 border-dashed border-navy/20 dark:border-navy/30 rounded-xl p-12 text-center">
                  <Camera className="h-12 w-12 mx-auto text-navy/40 dark:text-navy/60 mb-4" />
                  <p className="text-navy/60 dark:text-navy/80 mb-2">Take a selfie for style analysis</p>
                  <Button className="mt-4">
                    <Camera className="h-4 w-4 mr-2" />
                    Open Camera
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="mt-6">
              <h4 className="font-medium mb-3">What are you looking for?</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 text-center bg-navy text-white">
                  <i className="ri-scissors-line text-2xl"></i>
                  <p className="mt-1 text-sm">Haircut</p>
                </div>
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 text-center hover:border-bronze dark:hover:border-bronze cursor-pointer transition-all">
                  <i className="ri-brush-line text-2xl"></i>
                  <p className="mt-1 text-sm">Hair Color</p>
                </div>
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 text-center hover:border-bronze dark:hover:border-bronze cursor-pointer transition-all">
                  <i className="ri-palette-line text-2xl"></i>
                  <p className="mt-1 text-sm">Makeup</p>
                </div>
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 text-center hover:border-bronze dark:hover:border-bronze cursor-pointer transition-all">
                  <i className="ri-ink-bottle-line text-2xl"></i>
                  <p className="mt-1 text-sm">Nail Art</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full bg-bronze hover:bg-bronze-dark text-white"
              disabled={!uploadedImage || isAnalyzing}
              onClick={handleAnalyze}
            >
              {isAnalyzing ? "Analyzing..." : "Get Recommendations"}
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <>
          {/* Results view */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Your Photo</CardTitle>
                </CardHeader>
                <CardContent>
                  <img 
                    src={uploadedImage!} 
                    alt="Uploaded" 
                    className="w-full rounded-lg"
                  />
                  
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-300">Hair Length</span>
                      <Badge>Medium</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-300">Hair Type</span>
                      <Badge>Wavy</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-300">Face Shape</span>
                      <Badge>Oval</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-300">Skin Tone</span>
                      <Badge>Medium</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Styles</CardTitle>
                  <CardDescription>
                    Based on your features, these styles would complement you best
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-4 overflow-x-auto pb-2">
                      <div className="flex-shrink-0 w-36 border rounded-lg overflow-hidden cursor-pointer hover:border-bronze">
                        <img 
                          src="https://images.unsplash.com/photo-1605497788044-5a32c7078486?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=250&q=80" 
                          alt="Style 1" 
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-2 text-center">
                          <p className="font-medium text-sm">Layered Bob</p>
                          <div className="flex justify-center items-center mt-1">
                            <Star className="h-3 w-3 fill-current text-yellow-400" />
                            <span className="text-xs ml-1">98% Match</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-shrink-0 w-36 border rounded-lg overflow-hidden cursor-pointer hover:border-bronze">
                        <img 
                          src="https://images.unsplash.com/photo-1565538420870-da08ff96a207?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=250&q=80" 
                          alt="Style 2" 
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-2 text-center">
                          <p className="font-medium text-sm">Beach Waves</p>
                          <div className="flex justify-center items-center mt-1">
                            <Star className="h-3 w-3 fill-current text-yellow-400" />
                            <span className="text-xs ml-1">94% Match</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-shrink-0 w-36 border rounded-lg overflow-hidden cursor-pointer hover:border-bronze">
                        <img 
                          src="https://images.unsplash.com/photo-1492106087820-71f1a00d2b11?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=250&q=80" 
                          alt="Style 3" 
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-2 text-center">
                          <p className="font-medium text-sm">Curtain Bangs</p>
                          <div className="flex justify-center items-center mt-1">
                            <Star className="h-3 w-3 fill-current text-yellow-400" />
                            <span className="text-xs ml-1">90% Match</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-shrink-0 w-36 border rounded-lg overflow-hidden cursor-pointer hover:border-bronze">
                        <img 
                          src="https://images.unsplash.com/photo-1567954879083-5db791c25cd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=250&q=80" 
                          alt="Style 4" 
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-2 text-center">
                          <p className="font-medium text-sm">Long Layers</p>
                          <div className="flex justify-center items-center mt-1">
                            <Star className="h-3 w-3 fill-current text-yellow-400" />
                            <span className="text-xs ml-1">86% Match</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Recommended Services</h3>
                      <div className="space-y-4">
                        <ServiceCard
                          service={{
                            id: 1,
                            salonId: 1,
                            categoryId: 1,
                            name: "Layered Bob Haircut",
                            description: "A modern, textured bob with layers that frame your face perfectly. Ideal for your oval face shape and medium length hair.",
                            price: 99900,
                            duration: 60,
                            imageUrl: "https://images.unsplash.com/photo-1605497788044-5a32c7078486?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80",
                            isPopular: true,
                            gender: "female",
                            tags: ["haircut", "bob", "layers"]
                          }}
                          onBook={() => navigate("/booking/1/1")}
                        />
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Recommended Salons</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <SalonCard
                          salon={{
                            id: 1,
                            userId: 1,
                            name: "Glamour Studio",
                            description: "Premium salon specializing in modern haircuts and styling",
                            address: "123 Fashion Street",
                            city: "Mumbai",
                            state: "Maharashtra",
                            pincode: "400001",
                            contactNumber: "9876543210",
                            isVerified: true,
                            rating: 4.8,
                            totalRating: 480,
                            totalReviews: 100,
                            tags: ["Haircut", "Styling", "Premium"]
                          }}
                          onBookNow={() => navigate("/salon/1")}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setShowResults(false)}
                  >
                    Try Another Photo
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </>
      )}
    </>
  );
}
