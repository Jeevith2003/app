import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Wallet as WalletIcon, PlusCircle, ArrowDownUp, Calendar } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { useAuth } from "@/components/providers/AuthProvider";

export default function Wallet() {
  const { profile } = useAuth();
  
  // Fetch wallet transactions
  const { data: transactionsData, isLoading } = useQuery({
    queryKey: ['/api/customer/wallet/transactions'],
  });
  
  const walletBalance = profile?.walletBalance || 0;
  const transactions = transactionsData?.transactions || [];
  
  return (
    <>
      <h1 className="text-2xl font-playfair font-semibold mb-6">My Wallet</h1>
      
      {/* Wallet Balance Card */}
      <Card className="bg-navy text-white mb-8">
        <CardContent className="p-6">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-white/80 mb-1">Available Balance</p>
              <h2 className="text-3xl font-semibold">{formatPrice(walletBalance)}</h2>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <WalletIcon className="h-6 w-6" />
            </div>
          </div>
          
          <div className="flex gap-3 mt-6">
            <Button className="bg-bronze hover:bg-bronze-dark text-white">
              <PlusCircle className="h-4 w-4 mr-2" />
              Add Money
            </Button>
            <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white">
              <ArrowDownUp className="h-4 w-4 mr-2" />
              Transfer
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Transaction History */}
      <Tabs defaultValue="all">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Transaction History</h3>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="credits">Credits</TabsTrigger>
            <TabsTrigger value="debits">Debits</TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="all">
          {isLoading ? (
            <div className="flex justify-center items-center min-h-[30vh]">
              <span className="loading loading-spinner"></span>
            </div>
          ) : transactions.length === 0 ? (
            <EmptyTransactions />
          ) : (
            <div className="space-y-4">
              <TransactionGroup date="Today" transactions={[
                {
                  id: 1,
                  type: "credit",
                  amount: 20000,
                  description: "Referral bonus",
                  time: "10:30 AM"
                },
                {
                  id: 2,
                  type: "debit",
                  amount: 50000,
                  description: "Payment for haircut & styling",
                  time: "09:15 AM"
                }
              ]} />
              
              <TransactionGroup date="Yesterday" transactions={[
                {
                  id: 3,
                  type: "credit",
                  amount: 10000,
                  description: "Cashback",
                  time: "05:45 PM"
                }
              ]} />
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="credits">
          {isLoading ? (
            <div className="flex justify-center items-center min-h-[30vh]">
              <span className="loading loading-spinner"></span>
            </div>
          ) : (
            <div className="space-y-4">
              <TransactionGroup date="Today" transactions={[
                {
                  id: 1,
                  type: "credit",
                  amount: 20000,
                  description: "Referral bonus",
                  time: "10:30 AM"
                }
              ]} />
              
              <TransactionGroup date="Yesterday" transactions={[
                {
                  id: 3,
                  type: "credit",
                  amount: 10000,
                  description: "Cashback",
                  time: "05:45 PM"
                }
              ]} />
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="debits">
          {isLoading ? (
            <div className="flex justify-center items-center min-h-[30vh]">
              <span className="loading loading-spinner"></span>
            </div>
          ) : (
            <div className="space-y-4">
              <TransactionGroup date="Today" transactions={[
                {
                  id: 2,
                  type: "debit",
                  amount: 50000,
                  description: "Payment for haircut & styling",
                  time: "09:15 AM"
                }
              ]} />
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}

function EmptyTransactions() {
  return (
    <div className="text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
      <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
        <ArrowDownUp className="h-8 w-8 text-gray-400" />
      </div>
      <h3 className="text-lg font-medium dark:text-white">No Transactions Yet</h3>
      <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
        Your transaction history will appear here once you start using your wallet.
      </p>
    </div>
  );
}

interface Transaction {
  id: number;
  type: "credit" | "debit";
  amount: number;
  description: string;
  time: string;
}

function TransactionGroup({ date, transactions }: { date: string; transactions: Transaction[] }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center">
          <Calendar className="h-4 w-4 mr-2 text-gray-500" />
          <CardTitle className="text-base">{date}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex justify-between items-center py-2 border-b last:border-0">
            <div>
              <p className="font-medium dark:text-white">{transaction.description}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{transaction.time}</p>
            </div>
            <div className="flex items-center">
              <Badge className={transaction.type === "credit" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"}>
                {transaction.type === "credit" ? "+" : "-"}
                {formatPrice(transaction.amount)}
              </Badge>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
