import React, { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/components/providers/AuthProvider";
import { login } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Eye, EyeOff, Mail, Phone, User, Key } from "lucide-react";

const loginSchema = z.object({
  identifier: z.string().min(1, "Username, email or phone number is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type LoginFormData = z.infer<typeof loginSchema>;

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { login: authLogin } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      identifier: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    try {
      // Determine if the identifier is an email, phone, or username
      const isEmail = data.identifier.includes('@');
      const isPhone = /^\d+$/.test(data.identifier);
      
      // For now, our backend only supports username login, so we'll treat all identifiers as usernames
      // In a real implementation, we'd handle all three types differently
      const response = await login(data.identifier, data.password);
      
      if (response.user) {
        authLogin(response.user);
        toast({
          title: "Login Successful",
          description: "Welcome back to Booqin!",
          variant: "default",
        });
        
        // Redirect based on user type
        if (response.user.userType === "customer") {
          setLocation("/customer/home");
        } else {
          setLocation("/client/dashboard");
        }
      }
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-navy to-navy-dark p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-playfair font-bold text-white">
            Boo<span className="text-bronze">qin</span>
          </h1>
          <p className="mt-2 text-white/70">
            Where Beauty Meets Precision, Tailored for You
          </p>
        </div>
        
        <Card className="border-0 shadow-2xl bg-white/10 backdrop-blur-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-2xl text-white text-center">Welcome Back</CardTitle>
            <CardDescription className="text-white/70 text-center">
              Login to your account to continue
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="identifier" className="text-white">
                    Username, Email or Phone
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <User size={18} />
                    </div>
                    <Input
                      id="identifier"
                      type="text"
                      placeholder="Enter your username, email or phone"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                      {...register("identifier")}
                    />
                  </div>
                  {errors.identifier && (
                    <p className="text-red-400 text-sm mt-1">{errors.identifier.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">
                    Password
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <Key size={18} />
                    </div>
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      className="pl-10 pr-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                      {...register("password")}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-white/70 hover:text-white"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="text-red-400 text-sm mt-1">{errors.password.message}</p>
                  )}
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember"
                      type="checkbox"
                      className="h-4 w-4 rounded border-white/20 bg-white/10 text-bronze focus:ring-bronze"
                    />
                    <label htmlFor="remember" className="ml-2 block text-sm text-white/70">
                      Remember me
                    </label>
                  </div>
                  
                  <div className="text-sm">
                    <Link to="/auth/forgot-password" className="text-bronze hover:text-bronze-light">
                      Forgot password?
                    </Link>
                  </div>
                </div>
                
                <Button
                  type="submit"
                  className="w-full bg-bronze-light hover:bg-bronze text-white btn-hover-effect"
                  disabled={isLoading}
                >
                  {isLoading ? "Logging in..." : "Login"}
                </Button>
              </div>
            </form>
          </CardContent>
          
          <div className="px-6 py-4 flex items-center justify-between">
            <div className="h-px bg-white/10 flex-grow"></div>
            <span className="text-white/50 text-sm px-3">OR</span>
            <div className="h-px bg-white/10 flex-grow"></div>
          </div>
          
          <CardFooter className="flex flex-col space-y-4 pt-0">
            <div className="flex justify-center space-x-4 w-full">
              <button className="flex items-center justify-center h-10 w-10 rounded-full bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-colors">
                <i className="ri-google-fill text-lg"></i>
              </button>
              <button className="flex items-center justify-center h-10 w-10 rounded-full bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-colors">
                <i className="ri-facebook-fill text-lg"></i>
              </button>
              <button className="flex items-center justify-center h-10 w-10 rounded-full bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-colors">
                <i className="ri-apple-fill text-lg"></i>
              </button>
            </div>
            
            <div className="text-center text-white/70">
              Don't have an account?{" "}
              <Link to="/auth/register" className="text-bronze hover:text-bronze-light">
                Sign up
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}