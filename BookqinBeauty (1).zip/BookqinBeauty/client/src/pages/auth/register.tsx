import React, { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { register as registerUser } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { User, Mail, Phone, Key, Building, UserRound } from "lucide-react";

const customerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z.string().min(10, "Phone number must be at least 10 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
  userType: z.literal("customer"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

const clientSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z.string().min(10, "Phone number must be at least 10 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
  userType: z.literal("client"),
  name: z.string().min(1, "Business name is required"),
  address: z.string().min(1, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  pincode: z.string().min(4, "Pin code is required"),
  contactNumber: z.string().min(10, "Contact number must be at least 10 characters"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type CustomerFormData = z.infer<typeof customerSchema>;
type ClientFormData = z.infer<typeof clientSchema>;

export default function RegisterPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [userType, setUserType] = useState<"customer" | "client">("customer");
  const [isLoading, setIsLoading] = useState(false);

  const customerForm = useForm<CustomerFormData>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      username: "",
      email: "",
      phoneNumber: "",
      password: "",
      confirmPassword: "",
      userType: "customer",
      firstName: "",
      lastName: "",
    },
  });

  const clientForm = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      username: "",
      email: "",
      phoneNumber: "",
      password: "",
      confirmPassword: "",
      userType: "client",
      name: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      contactNumber: "",
    },
  });

  const onCustomerSubmit = async (data: CustomerFormData) => {
    setIsLoading(true);
    try {
      const response = await registerUser({
        username: data.username,
        email: data.email,
        phoneNumber: data.phoneNumber,
        password: data.password,
        userType: "customer",
        profile: {
          firstName: data.firstName,
          lastName: data.lastName,
        },
      });

      toast({
        title: "Registration Successful",
        description: "Welcome to Booqin! You're now registered as a customer.",
        variant: "default",
      });

      setLocation("/customer/home");
    } catch (error: any) {
      console.error("Registration error:", error);
      toast({
        title: "Registration Failed",
        description: error?.message || "Registration failed. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onClientSubmit = async (data: ClientFormData) => {
    setIsLoading(true);
    try {
      const response = await registerUser({
        username: data.username,
        email: data.email,
        phoneNumber: data.phoneNumber,
        password: data.password,
        userType: "client",
        profile: {
          name: data.name,
          address: data.address,
          city: data.city,
          state: data.state,
          pincode: data.pincode,
          contactNumber: data.contactNumber,
        },
      });

      toast({
        title: "Registration Successful",
        description: "Welcome to Booqin! You're now registered as a client.",
        variant: "default",
      });

      setLocation("/client/dashboard");
    } catch (error: any) {
      console.error("Registration error:", error);
      toast({
        title: "Registration Failed",
        description: error?.message || "Registration failed. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-navy to-navy-dark p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-playfair font-bold text-white">
            Boo<span className="text-bronze">qin</span>
          </h1>
          <p className="mt-2 text-white/70">
            Where Beauty Meets Precision, Tailored for You
          </p>
        </div>
        
        <Card className="border-0 shadow-2xl bg-white/10 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl text-white text-center">Create Account</CardTitle>
            <CardDescription className="text-white/70 text-center">
              Join Booqin to discover beauty services
            </CardDescription>
          </CardHeader>
          
          <Tabs 
            value={userType} 
            onValueChange={(value) => setUserType(value as "customer" | "client")}
            className="w-full"
          >
            <div className="px-6">
              <TabsList className="grid grid-cols-2 w-full bg-white/10">
                <TabsTrigger value="customer" className="data-[state=active]:bg-bronze data-[state=active]:text-white text-white/70">
                  Customer
                </TabsTrigger>
                <TabsTrigger value="client" className="data-[state=active]:bg-bronze data-[state=active]:text-white text-white/70">
                  Client
                </TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="customer" className="pt-4">
              <CardContent>
                <form onSubmit={customerForm.handleSubmit(onCustomerSubmit)}>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="text-white">
                          First Name
                        </Label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <UserRound size={16} />
                          </div>
                          <Input
                            id="firstName"
                            placeholder="First name"
                            className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                            {...customerForm.register("firstName")}
                          />
                        </div>
                        {customerForm.formState.errors.firstName && (
                          <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.firstName.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="text-white">
                          Last Name
                        </Label>
                        <Input
                          id="lastName"
                          placeholder="Last name"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...customerForm.register("lastName")}
                        />
                        {customerForm.formState.errors.lastName && (
                          <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.lastName.message}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-white">
                        Username
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <User size={16} />
                        </div>
                        <Input
                          id="username"
                          placeholder="Choose a username"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...customerForm.register("username")}
                        />
                      </div>
                      {customerForm.formState.errors.username && (
                        <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.username.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white">
                        Email
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Mail size={16} />
                        </div>
                        <Input
                          id="email"
                          type="email"
                          placeholder="Your email address"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...customerForm.register("email")}
                        />
                      </div>
                      {customerForm.formState.errors.email && (
                        <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.email.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phoneNumber" className="text-white">
                        Phone Number
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Phone size={16} />
                        </div>
                        <Input
                          id="phoneNumber"
                          placeholder="Your phone number"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...customerForm.register("phoneNumber")}
                        />
                      </div>
                      {customerForm.formState.errors.phoneNumber && (
                        <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.phoneNumber.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-white">
                        Password
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Key size={16} />
                        </div>
                        <Input
                          id="password"
                          type="password"
                          placeholder="Create a password"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...customerForm.register("password")}
                        />
                      </div>
                      {customerForm.formState.errors.password && (
                        <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.password.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-white">
                        Confirm Password
                      </Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirm your password"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                        {...customerForm.register("confirmPassword")}
                      />
                      {customerForm.formState.errors.confirmPassword && (
                        <p className="text-red-400 text-sm mt-1">{customerForm.formState.errors.confirmPassword.message}</p>
                      )}
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full bg-bronze-light hover:bg-bronze text-white btn-hover-effect"
                      disabled={isLoading}
                    >
                      {isLoading ? "Creating account..." : "Sign Up as Customer"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="client" className="pt-4">
              <CardContent>
                <form onSubmit={clientForm.handleSubmit(onClientSubmit)}>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white">
                        Business Name
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Building size={16} />
                        </div>
                        <Input
                          id="name"
                          placeholder="Your salon or spa name"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("name")}
                        />
                      </div>
                      {clientForm.formState.errors.name && (
                        <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.name.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-white">
                        Username
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <User size={16} />
                        </div>
                        <Input
                          id="username"
                          placeholder="Choose a username"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("username")}
                        />
                      </div>
                      {clientForm.formState.errors.username && (
                        <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.username.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white">
                        Email
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Mail size={16} />
                        </div>
                        <Input
                          id="email"
                          type="email"
                          placeholder="Business email address"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("email")}
                        />
                      </div>
                      {clientForm.formState.errors.email && (
                        <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.email.message}</p>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phoneNumber" className="text-white">
                          Login Phone
                        </Label>
                        <Input
                          id="phoneNumber"
                          placeholder="Phone for login"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("phoneNumber")}
                        />
                        {clientForm.formState.errors.phoneNumber && (
                          <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.phoneNumber.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="contactNumber" className="text-white">
                          Business Phone
                        </Label>
                        <Input
                          id="contactNumber"
                          placeholder="Public contact number"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("contactNumber")}
                        />
                        {clientForm.formState.errors.contactNumber && (
                          <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.contactNumber.message}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="address" className="text-white">
                        Address
                      </Label>
                      <Input
                        id="address"
                        placeholder="Business address"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                        {...clientForm.register("address")}
                      />
                      {clientForm.formState.errors.address && (
                        <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.address.message}</p>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="city" className="text-white">
                          City
                        </Label>
                        <Input
                          id="city"
                          placeholder="City"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("city")}
                        />
                        {clientForm.formState.errors.city && (
                          <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.city.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="state" className="text-white">
                          State
                        </Label>
                        <Input
                          id="state"
                          placeholder="State"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("state")}
                        />
                        {clientForm.formState.errors.state && (
                          <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.state.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="pincode" className="text-white">
                          Pin Code
                        </Label>
                        <Input
                          id="pincode"
                          placeholder="Pin code"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("pincode")}
                        />
                        {clientForm.formState.errors.pincode && (
                          <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.pincode.message}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-white">
                        Password
                      </Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Key size={16} />
                        </div>
                        <Input
                          id="password"
                          type="password"
                          placeholder="Create a password"
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          {...clientForm.register("password")}
                        />
                      </div>
                      {clientForm.formState.errors.password && (
                        <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.password.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-white">
                        Confirm Password
                      </Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirm your password"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                        {...clientForm.register("confirmPassword")}
                      />
                      {clientForm.formState.errors.confirmPassword && (
                        <p className="text-red-400 text-sm mt-1">{clientForm.formState.errors.confirmPassword.message}</p>
                      )}
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full bg-bronze-light hover:bg-bronze text-white btn-hover-effect"
                      disabled={isLoading}
                    >
                      {isLoading ? "Creating account..." : "Sign Up as Client"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </TabsContent>
          </Tabs>
          
          <CardFooter className="pt-2 pb-6">
            <div className="text-center w-full text-white/70">
              Already have an account?{" "}
              <Link to="/auth/login" className="text-bronze hover:text-bronze-light font-medium">
                Login
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}