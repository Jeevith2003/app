import React, { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Mail, ArrowLeft } from "lucide-react";

const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type ForgotPasswordFormData = z.infer<typeof forgotPasswordSchema>;

export default function ForgotPasswordPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordFormData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit = async (data: ForgotPasswordFormData) => {
    setIsLoading(true);
    try {
      // Here we'd typically call an API endpoint to send a password reset email
      // For now, we'll just simulate success
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setResetSent(true);
      
      toast({
        title: "Reset Email Sent",
        description: "If an account exists with this email, you'll receive password reset instructions.",
        variant: "default",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || "Failed to send reset email. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-navy to-navy-dark p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-playfair font-bold text-white">
            Boo<span className="text-bronze">qin</span>
          </h1>
          <p className="mt-2 text-white/70">
            Where Beauty Meets Precision, Tailored for You
          </p>
        </div>
        
        <Card className="border-0 shadow-2xl bg-white/10 backdrop-blur-sm">
          <CardHeader>
            <Link to="/auth/login" className="text-white/70 hover:text-white inline-flex items-center mb-2">
              <ArrowLeft size={16} className="mr-1" />
              Back to login
            </Link>
            <CardTitle className="text-2xl text-white text-center">Reset Password</CardTitle>
            <CardDescription className="text-white/70 text-center">
              {!resetSent ? 
                "Enter your email to receive reset instructions" : 
                "Check your email for reset instructions"}
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {!resetSent ? (
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white">
                      Email Address
                    </Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <Mail size={18} />
                      </div>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your registered email"
                        className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                        {...register("email")}
                      />
                    </div>
                    {errors.email && (
                      <p className="text-red-400 text-sm mt-1">{errors.email.message}</p>
                    )}
                  </div>
                  
                  <Button
                    type="submit"
                    className="w-full bg-bronze-light hover:bg-bronze text-white btn-hover-effect"
                    disabled={isLoading}
                  >
                    {isLoading ? "Sending instructions..." : "Send Reset Instructions"}
                  </Button>
                </div>
              </form>
            ) : (
              <div className="p-4 rounded-md bg-white/5 text-center">
                <p className="text-white mb-4">
                  We've sent password reset instructions to your email address. 
                  Please check your inbox (and spam folder) for further instructions.
                </p>
                <Button
                  onClick={() => setLocation("/auth/login")}
                  className="bg-bronze-light hover:bg-bronze text-white btn-hover-effect"
                >
                  Return to Login
                </Button>
              </div>
            )}
          </CardContent>
          
          <CardFooter className="pt-0 pb-6">
            <div className="text-center w-full text-white/70">
              Remember your password?{" "}
              <Link to="/auth/login" className="text-bronze hover:text-bronze-light font-medium">
                Log in
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}