import { queryClient, apiRequest } from "./queryClient";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const GPT_MODEL = "gpt-4o";

// AI Style Analysis
export interface StyleAnalysisRequest {
  imageBase64: string;
  styleType: 'haircut' | 'haircolor' | 'makeup' | 'nailart';
  gender?: string;
}

export interface StyleAnalysisResponse {
  faceShape?: string;
  hairType?: string;
  hairLength?: string;
  skinTone?: string;
  recommendations: StyleRecommendation[];
}

export interface StyleRecommendation {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  matchPercentage: number;
}

export async function analyzeStyle(request: StyleAnalysisRequest): Promise<StyleAnalysisResponse> {
  try {
    const response = await apiRequest("POST", "/api/customer/ai/style-analysis", request);
    return await response.json();
  } catch (error) {
    console.error("Error analyzing style:", error);
    
    // Return mock data for display purposes only if API fails
    return {
      faceShape: "Oval",
      hairType: "Wavy",
      hairLength: "Medium",
      skinTone: "Medium",
      recommendations: [
        {
          id: "1",
          name: "Layered Bob",
          description: "A modern, textured bob with layers that frame your face perfectly.",
          imageUrl: "https://images.unsplash.com/photo-1605497788044-5a32c7078486?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80",
          matchPercentage: 98
        },
        {
          id: "2",
          name: "Beach Waves",
          description: "Natural-looking waves that add texture and movement.",
          imageUrl: "https://images.unsplash.com/photo-1565538420870-da08ff96a207?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80",
          matchPercentage: 94
        },
        {
          id: "3",
          name: "Curtain Bangs",
          description: "Soft, face-framing bangs that part in the middle.",
          imageUrl: "https://images.unsplash.com/photo-1492106087820-71f1a00d2b11?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80",
          matchPercentage: 90
        }
      ]
    };
  }
}

// AI Chatbot
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ChatResponse {
  message: ChatMessage;
  sessionId?: string;
}

export async function sendChatMessage(message: string, sessionId?: string): Promise<ChatResponse> {
  try {
    const response = await apiRequest("POST", "/api/customer/ai/chat", {
      message,
      sessionId
    });
    return await response.json();
  } catch (error) {
    console.error("Error sending chat message:", error);
    throw new Error("Failed to get response from AI assistant");
  }
}
