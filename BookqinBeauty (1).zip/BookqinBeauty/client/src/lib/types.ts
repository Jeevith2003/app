import { User, Customer, Salon, Service, Booking, Review } from "@shared/schema";

// Extended user with profile
export type UserWithProfile = User & {
  profile?: Customer | Salon;
};

// Authentication context state
export interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  profile: Customer | Salon | null;
}

// Theme types
export type Theme = "light" | "dark";

// Notification
export interface Notification {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: Date;
}

// AI Style Recommendation
export interface StyleRecommendation {
  id: string;
  imageUrl: string;
  name: string;
  description: string;
  confidence: number;
}

// Service Category
export interface ServiceCategory {
  id: number;
  name: string;
  icon: string;
  imageUrl?: string;
}

// Special Offer
export interface Offer {
  id: number;
  title: string;
  description: string;
  code: string;
  discountType: "percentage" | "fixed";
  discountValue: number;
  minAmount?: number;
  maxDiscount?: number;
  startDate: Date;
  endDate: Date;
  isActive: boolean;
  gradient?: string;
  backgroundColor?: string;
}

// Service with salon info
export interface ServiceWithSalon extends Service {
  salon?: Salon;
}

// Booking with service and salon info
export interface BookingWithDetails extends Booking {
  service?: Service;
  salon?: Salon;
}

// Review with customer info
export interface ReviewWithCustomer extends Review {
  customerName?: string;
  customerImage?: string;
}

// Dashboard stats
export interface DashboardStats {
  todayBookings: number;
  todayRevenue: number;
  totalCustomers: number;
  rating: number;
  totalReviews: number;
  comparedToYesterday: {
    bookings: number;
    revenue: number;
  };
}
