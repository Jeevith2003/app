export type Theme = 'light' | 'dark';

export function getSystemTheme(): Theme {
  if (typeof window !== 'undefined' && window.matchMedia) {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  return 'light';
}

export function applyTheme(theme: Theme) {
  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    
    // Save preference to localStorage
    localStorage.setItem('theme', theme);
  }
}

export function getSavedTheme(): Theme | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('theme') as Theme | null;
  }
  return null;
}

export function initializeTheme() {
  // Check local storage first
  const savedTheme = getSavedTheme();
  
  if (savedTheme) {
    applyTheme(savedTheme);
    return;
  }
  
  // If no saved preference, use system preference
  const systemTheme = getSystemTheme();
  applyTheme(systemTheme);
}
