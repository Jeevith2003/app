import { ServiceCategory, Offer } from "./types";

// Navigation items for customer
export const CUSTOMER_NAV_ITEMS = [
  { name: "Home", path: "/", icon: "ri-home-5-line" },
  { name: "Bookings", path: "/bookings", icon: "ri-calendar-line" },
  { name: "Wallet", path: "/wallet", icon: "ri-wallet-3-line" },
  { name: "Profile", path: "/profile", icon: "ri-user-line" },
];

// Navigation items for salon owner
export const SALON_NAV_ITEMS = [
  { name: "Dashboard", path: "/salon", icon: "ri-dashboard-line" },
  { name: "Bookings", path: "/salon/bookings", icon: "ri-calendar-check-line" },
  { name: "Services", path: "/salon/services", icon: "ri-scissors-line" },
  { name: "Staff", path: "/salon/staff", icon: "ri-team-line" },
  { name: "Earnings", path: "/salon/earnings", icon: "ri-money-dollar-circle-line" },
  { name: "Reviews", path: "/salon/reviews", icon: "ri-star-line" },
  { name: "Profile", path: "/salon/profile", icon: "ri-store-line" },
];

// Service categories
export const SERVICE_CATEGORIES: ServiceCategory[] = [
  { id: 1, name: "Hair", icon: "ri-scissors-line", imageUrl: "https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80" },
  { id: 2, name: "Makeup", icon: "ri-brush-line", imageUrl: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80" },
  { id: 3, name: "Spa", icon: "ri-emotion-happy-line", imageUrl: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80" },
  { id: 4, name: "Nail Care", icon: "ri-hand-heart-line", imageUrl: "https://images.unsplash.com/photo-1604654894610-df63bc536371?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80" },
];

// Sample offers
export const SAMPLE_OFFERS: Offer[] = [
  {
    id: 1,
    title: "New User Discount",
    description: "Get 30% off on your first booking with us!",
    code: "NEW30",
    discountType: "percentage",
    discountValue: 30,
    startDate: new Date("2023-01-01"),
    endDate: new Date("2023-12-31"),
    isActive: true,
    gradient: "from-navy to-navy-light",
  },
  {
    id: 2,
    title: "Weekend Special",
    description: "Flat ₹500 off on any service booking above ₹1500",
    code: "WEEKEND500",
    discountType: "fixed",
    discountValue: 50000, // 500 in paisa
    minAmount: 150000, // 1500 in paisa
    startDate: new Date("2023-01-01"),
    endDate: new Date("2023-12-31"),
    isActive: true,
    backgroundColor: "bg-white",
  },
  {
    id: 3,
    title: "Refer & Earn",
    description: "Refer a friend and get ₹200 in your wallet!",
    code: "REFER200",
    discountType: "fixed",
    discountValue: 20000, // 200 in paisa
    startDate: new Date("2023-01-01"),
    endDate: new Date("2023-12-31"),
    isActive: true,
    gradient: "from-bronze-light to-bronze",
  },
];

// Booking statuses with labels and colors
export const BOOKING_STATUS_CONFIG = {
  pending: {
    label: "Pending",
    color: "bg-yellow-100 text-yellow-800",
    icon: "ri-time-line",
  },
  confirmed: {
    label: "Confirmed",
    color: "bg-green-100 text-green-800",
    icon: "ri-check-line",
  },
  completed: {
    label: "Completed",
    color: "bg-blue-100 text-blue-800",
    icon: "ri-checkbox-circle-line",
  },
  cancelled: {
    label: "Cancelled",
    color: "bg-red-100 text-red-800",
    icon: "ri-close-circle-line",
  },
};

// Time slots for booking
export const TIME_SLOTS = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
  "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
  "18:00", "18:30", "19:00", "19:30", "20:00"
];
