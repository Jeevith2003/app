import { Link, useLocation } from "wouter";
import { CUSTOMER_NAV_ITEMS } from "@/lib/constants";
import { useAuth } from "@/components/providers/AuthProvider";
import { useTheme } from "@/components/providers/ThemeProvider";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";
import { Loader, BellRing, Sun, Moon, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

type CustomerLayoutProps = {
  children: React.ReactNode;
};

export default function CustomerLayout({ children }: CustomerLayoutProps) {
  const { user, profile, isLoading, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader className="h-8 w-8 animate-spin text-bronze" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-softWhite dark:bg-gray-900">
      {/* Header */}
      <header className="bg-navy dark:bg-navy-dark text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-playfair font-bold">BookQin</h1>
            <span className="ml-2 text-bronze">Beauty</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-white">
              <BellRing className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-white" onClick={toggleTheme}>
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Avatar>
              <AvatarImage src={profile?.profileImage} />
              <AvatarFallback>{getInitials(user?.username || "")}</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 pb-20 flex-1">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-2 px-4 z-40">
        <div className="flex justify-between items-center">
          {CUSTOMER_NAV_ITEMS.map((item, index) => {
            const isActive = location === item.path;
            return (
              <Link key={index} href={item.path}>
                <a className={`flex flex-col items-center ${isActive ? 'text-bronze' : 'text-gray-500 dark:text-gray-400'}`}>
                  <i className={`${item.icon} text-xl`}></i>
                  <span className="text-xs mt-1">{item.name}</span>
                </a>
              </Link>
            );
          })}
          <Button 
            variant="ghost" 
            className="flex flex-col items-center text-gray-500 dark:text-gray-400"
            onClick={() => logout()}
          >
            <LogOut className="h-5 w-5" />
            <span className="text-xs mt-1">Logout</span>
          </Button>
        </div>
      </nav>
    </div>
  );
}
