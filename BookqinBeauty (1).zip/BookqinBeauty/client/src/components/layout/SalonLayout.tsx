import { useState } from "react";
import { Link, useLocation } from "wouter";
import { SALON_NAV_ITEMS } from "@/lib/constants";
import { useAuth } from "@/components/providers/AuthProvider";
import { useTheme } from "@/components/providers/ThemeProvider";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { getInitials } from "@/lib/utils";
import { Loader, BellRing, Sun, Moon, Menu, X } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

type SalonLayoutProps = {
  children: React.ReactNode;
};

export default function SalonLayout({ children }: SalonLayoutProps) {
  const { user, profile, isLoading, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader className="h-8 w-8 animate-spin text-bronze" />
      </div>
    );
  }

  const salonName = profile?.name || user?.username || "";
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-softWhite dark:bg-gray-900">
      {/* Sidebar for medium screens and up */}
      <div 
        className={`fixed md:static inset-y-0 left-0 w-64 bg-navy dark:bg-navy-dark text-white transform ${
          sidebarOpen || !isMobile ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 ease-in-out z-50`}
      >
        <div className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-playfair font-bold">BookQin</h1>
              <span className="text-bronze">Partner</span>
            </div>
            {isMobile && (
              <Button variant="ghost" size="icon" className="text-white md:hidden" onClick={toggleSidebar}>
                <X className="h-5 w-5" />
              </Button>
            )}
          </div>
          <p className="text-white/60 text-sm mt-1">Salon Management Portal</p>
        </div>
        
        {/* Salon navigation items */}
        <div className="mt-4">
          {SALON_NAV_ITEMS.map((item, index) => {
            const isActive = location === item.path;
            return (
              <Link key={index} href={item.path}>
                <a 
                  className={`w-full flex items-center text-left px-6 py-3 ${
                    isActive ? 'bg-navy-light dark:bg-navy' : 'hover:bg-navy-light dark:hover:bg-navy'
                  }`}
                  onClick={() => isMobile && setSidebarOpen(false)}
                >
                  <i className={`${item.icon} mr-3 text-lg`}></i>
                  <span>{item.name}</span>
                </a>
              </Link>
            );
          })}
        </div>
        
        <div className="mt-auto p-6">
          <div className="bg-navy-light dark:bg-navy rounded-lg p-4">
            <h3 className="font-medium">Need Help?</h3>
            <p className="text-white/70 text-sm mt-1">Contact our support team for assistance</p>
            <Button className="mt-3 w-full bg-bronze hover:bg-bronze-dark text-white py-2 rounded-lg text-sm">
              Contact Support
            </Button>
          </div>
          
          <Button 
            variant="ghost" 
            className="mt-6 w-full flex items-center text-white/70 hover:text-white"
            onClick={() => logout()}
          >
            <i className="ri-logout-box-line mr-2"></i>
            <span>Logout</span>
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 md:ml-64">
        {/* Top header for salon */}
        <header className="bg-white dark:bg-gray-800 shadow-sm p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              {isMobile && (
                <Button variant="ghost" size="icon" className="md:hidden mr-4" onClick={toggleSidebar}>
                  <Menu className="h-5 w-5" />
                </Button>
              )}
              <div className="flex items-center">
                <span className="text-lg font-medium text-gray-800 dark:text-gray-200">{salonName}</span>
                {profile?.isVerified && (
                  <div className="ml-2 flex items-center bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 px-2 py-0.5 rounded-full text-xs">
                    <i className="ri-verified-badge-fill mr-1"></i>
                    <span>Verified</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <BellRing className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={toggleTheme}>
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarImage src={profile?.profileImage} />
                  <AvatarFallback>{getInitials(salonName)}</AvatarFallback>
                </Avatar>
                <span className="hidden md:inline-block text-sm dark:text-gray-200">Salon Admin</span>
              </div>
            </div>
          </div>
        </header>
        
        {/* Page Content */}
        <div className="p-6">
          {children}
        </div>
      </div>
    </div>
  );
}
