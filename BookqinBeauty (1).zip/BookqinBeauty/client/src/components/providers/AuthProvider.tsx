import { createContext, useContext, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getSession, getUserProfile, logout } from "@/lib/auth";
import { AuthState } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

type AuthProviderProps = {
  children: React.ReactNode;
};

type AuthContextType = AuthState & {
  login: (user: User) => void;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: AuthProviderProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    isLoading: true,
    user: null,
    profile: null,
  });
  
  // Check session on mount
  const { data: sessionData, isLoading: isSessionLoading } = useQuery({
    queryKey: ['/api/auth/session'],
    retry: false,
  });
  
  // Fetch user profile if authenticated
  const { data: profileData, isLoading: isProfileLoading } = useQuery({
    queryKey: ['/api/user/profile'],
    enabled: !!sessionData?.authenticated,
    retry: false,
  });
  
  useEffect(() => {
    if (isSessionLoading) return;
    
    if (sessionData?.authenticated && sessionData?.user) {
      setAuthState(prev => ({
        ...prev,
        isAuthenticated: true,
        user: sessionData.user,
        isLoading: isProfileLoading,
      }));
    } else {
      setAuthState({
        isAuthenticated: false,
        isLoading: false,
        user: null,
        profile: null,
      });
    }
  }, [sessionData, isSessionLoading, isProfileLoading]);
  
  useEffect(() => {
    if (profileData?.profile) {
      setAuthState(prev => ({
        ...prev,
        profile: profileData.profile,
        isLoading: false,
      }));
    }
  }, [profileData]);
  
  const login = (user: User) => {
    setAuthState(prev => ({
      ...prev,
      isAuthenticated: true,
      user,
      isLoading: true,
    }));
    
    // Refetch profile
    queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      
      setAuthState({
        isAuthenticated: false,
        isLoading: false,
        user: null,
        profile: null,
      });
      
      // Clear all queries
      queryClient.clear();
      
      toast({
        title: "Logged out successfully",
        description: "You have been logged out.",
      });
    } catch (error) {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };
  
  return (
    <AuthContext.Provider
      value={{
        ...authState,
        login,
        logout: handleLogout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  
  return context;
};
