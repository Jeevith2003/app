import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/components/providers/AuthProvider";
import { Loader } from "lucide-react";
import CustomerLayout from "@/components/layout/CustomerLayout";
import SalonLayout from "@/components/layout/SalonLayout";

type ProtectedRouteProps = {
  component: React.ComponentType<any>;
  userType: "customer" | "client";
  [key: string]: any;
};

export default function ProtectedRoute({ 
  component: Component, 
  userType,
  ...rest 
}: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    } else if (!isLoading && isAuthenticated && user?.userType !== userType) {
      // Redirect to the correct dashboard based on user type
      if (user?.userType === "customer") {
        navigate("/");
      } else if (user?.userType === "client") {
        navigate("/salon");
      }
    }
  }, [isLoading, isAuthenticated, user, navigate, userType]);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader className="h-8 w-8 animate-spin text-bronze" />
      </div>
    );
  }

  if (!isAuthenticated || user?.userType !== userType) {
    return null; // Will redirect in useEffect
  }

  // Render with the appropriate layout
  if (userType === "customer") {
    return (
      <CustomerLayout>
        <Component {...rest} />
      </CustomerLayout>
    );
  } else {
    return (
      <SalonLayout>
        <Component {...rest} />
      </SalonLayout>
    );
  }
}
