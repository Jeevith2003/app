import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, MapPin, ArrowRight } from "lucide-react";

export function LandingHero() {
  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 hero-gradient opacity-95 z-0"></div>
      
      {/* Decorative elements */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-bronze opacity-10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-bronze opacity-10 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="animate-slideUp">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-playfair font-semibold text-white leading-tight">
              Where Beauty Meets <span className="text-bronze">Precision</span>,<br />
              <span className="text-bronze">Tailored</span> for You
            </h1>
            
            <p className="mt-6 text-lg text-white/80 max-w-lg">
              Discover and book the perfect beauty services from top salons.
              Your journey to looking and feeling your best starts here.
            </p>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-bronze hover:bg-bronze-dark text-white btn-hover-effect">
                Book Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Join as Salon
              </Button>
            </div>
            
            <div className="mt-12 grid grid-cols-3 gap-6">
              <div className="text-center">
                <h3 className="text-3xl font-semibold text-white">500+</h3>
                <p className="text-white/70 text-sm mt-1">Premium Salons</p>
              </div>
              <div className="text-center">
                <h3 className="text-3xl font-semibold text-white">10K+</h3>
                <p className="text-white/70 text-sm mt-1">Happy Customers</p>
              </div>
              <div className="text-center">
                <h3 className="text-3xl font-semibold text-white">50+</h3>
                <p className="text-white/70 text-sm mt-1">Cities Covered</p>
              </div>
            </div>
          </div>
          
          <div className="relative hidden md:block">
            <div className="absolute inset-0 bg-white/5 backdrop-blur-sm rounded-3xl"></div>
            <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-xl p-6 animate-slideUp animation-delay-150">
              <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Find Your Perfect Look</h3>
              
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="Haircut, Spa, Manicure..."
                    className="w-full rounded-lg border-gray-200 dark:border-gray-600 pl-10 py-2.5 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
                  />
                </div>
                
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="Your location"
                    className="w-full rounded-lg border-gray-200 dark:border-gray-600 pl-10 py-2.5 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
                  />
                </div>
                
                <Button size="lg" className="w-full bg-bronze hover:bg-bronze-dark text-white">
                  Search
                </Button>
              </div>
              
              <div className="mt-6 flex flex-wrap gap-2">
                <span className="text-sm text-gray-500 dark:text-gray-400">Popular:</span>
                <Link href="/search?q=haircut">
                  <a className="text-sm text-bronze hover:underline">Haircut</a>
                </Link>
                <Link href="/search?q=color">
                  <a className="text-sm text-bronze hover:underline">Hair Color</a>
                </Link>
                <Link href="/search?q=facial">
                  <a className="text-sm text-bronze hover:underline">Facial</a>
                </Link>
                <Link href="/search?q=makeup">
                  <a className="text-sm text-bronze hover:underline">Makeup</a>
                </Link>
              </div>
            </div>
            
            <div className="absolute -right-6 -bottom-6 w-24 h-24 rounded-full border-8 border-bronze/30 z-0"></div>
            <div className="absolute -left-12 -top-12 w-32 h-32 rounded-full border-8 border-bronze/20 z-0"></div>
          </div>
        </div>
      </div>
    </div>
  );
}