import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Upload, Sparkles } from "lucide-react";

export function AiStyleFeature() {
  return (
    <div className="relative py-16 overflow-hidden bg-gradient-to-br from-navy to-navy-dark">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-bronze/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-bronze/10 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="max-w-md mx-auto">
              <div className="relative bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 shadow-xl">
                <div className="absolute -top-3 -right-3">
                  <div className="flex items-center justify-center h-12 w-12 rounded-full bg-bronze text-white">
                    <Sparkles className="h-5 w-5" />
                  </div>
                </div>
                
                <h3 className="text-xl font-medium text-white mb-4">AI Style Match</h3>
                
                <div className="bg-white/5 border border-white/10 rounded-xl p-8 flex flex-col items-center justify-center">
                  <div className="h-20 w-20 rounded-full bg-bronze/20 flex items-center justify-center mb-4">
                    <Upload className="h-8 w-8 text-bronze" />
                  </div>
                  <p className="text-center text-white/80 text-sm">
                    Upload your photo and get personalized style recommendations
                  </p>
                </div>
                
                <div className="mt-6 grid grid-cols-3 gap-3">
                  <div className="bg-white/5 border border-white/10 rounded-lg p-2">
                    <img 
                      src="https://images.unsplash.com/photo-1580618864194-0ef9e2468556?q=80&w=200&h=200&auto=format&fit=crop"
                      alt="Hairstyle" 
                      className="w-full h-24 object-cover rounded-md"
                    />
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-lg p-2">
                    <img 
                      src="https://images.unsplash.com/photo-1595476108398-e6f75f98cfa2?q=80&w=200&h=200&auto=format&fit=crop"
                      alt="Haircolor" 
                      className="w-full h-24 object-cover rounded-md"
                    />
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-lg p-2">
                    <img 
                      src="https://images.unsplash.com/photo-1599842057874-37393e9342df?q=80&w=200&h=200&auto=format&fit=crop"
                      alt="Salon" 
                      className="w-full h-24 object-cover rounded-md"
                    />
                  </div>
                </div>
                
                <div className="mt-6">
                  <Link href="/ai-style">
                    <a className="block w-full">
                      <Button className="w-full bg-bronze hover:bg-bronze-dark text-white btn-hover-effect">
                        Try AI Style Match
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </a>
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          <div className="order-1 md:order-2">
            <div className="space-y-6 max-w-lg">
              <h2 className="text-3xl md:text-4xl font-playfair font-semibold text-white leading-tight">
                Discover Your <span className="text-bronze">Perfect Style</span> with AI
              </h2>
              
              <p className="text-white/80">
                Our AI-powered style recommendation system analyzes your features and preferences 
                to suggest hairstyles, colors, and beauty treatments perfectly suited to you.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-bronze flex items-center justify-center text-white">
                    <i className="ri-check-line"></i>
                  </div>
                  <p className="ml-3 text-white/80">
                    Upload a photo and get instant style recommendations
                  </p>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-bronze flex items-center justify-center text-white">
                    <i className="ri-check-line"></i>
                  </div>
                  <p className="ml-3 text-white/80">
                    Personalized suggestions based on face shape, skin tone, and features
                  </p>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-bronze flex items-center justify-center text-white">
                    <i className="ri-check-line"></i>
                  </div>
                  <p className="ml-3 text-white/80">
                    Inclusive recommendations for all genders and style preferences
                  </p>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-bronze flex items-center justify-center text-white">
                    <i className="ri-check-line"></i>
                  </div>
                  <p className="ml-3 text-white/80">
                    Book directly with salons that specialize in your recommended styles
                  </p>
                </div>
              </div>
              
              <div className="pt-4">
                <div className="flex -space-x-3">
                  <div className="h-10 w-10 rounded-full border-2 border-navy overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/women/44.jpg" 
                      alt="User" 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="h-10 w-10 rounded-full border-2 border-navy overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/men/32.jpg" 
                      alt="User" 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="h-10 w-10 rounded-full border-2 border-navy overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/women/68.jpg" 
                      alt="User" 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="h-10 w-10 rounded-full border-2 border-navy overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/men/75.jpg" 
                      alt="User" 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="h-10 w-10 rounded-full border-2 border-navy bg-bronze flex items-center justify-center text-white text-xs">
                    5k+
                  </div>
                </div>
                <p className="mt-2 text-white/70 text-sm">
                  Join thousands of customers who found their perfect style
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}