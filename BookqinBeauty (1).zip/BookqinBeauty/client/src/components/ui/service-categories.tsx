import React from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { SERVICE_CATEGORIES } from "@/lib/constants";

export function ServiceCategories() {
  return (
    <div className="py-16 bg-softWhite dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-playfair font-semibold text-gray-900 dark:text-white">
            Discover Our <span className="text-bronze">Premium</span> Services
          </h2>
          <p className="mt-4 text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            From classic styles to trendy transformations, we offer a wide range of beauty services for everyone.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {SERVICE_CATEGORIES.map((category) => (
            <Link key={category.id} href={`/category/${category.id}`}>
              <a>
                <Card className="service-card h-full bg-white dark:bg-gray-800 border-none overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300">
                  <div className="relative h-40 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent z-10"></div>
                    {category.imageUrl ? (
                      <img 
                        src={category.imageUrl} 
                        alt={category.name} 
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                        <i className={`${category.icon} text-4xl text-gray-400 dark:text-gray-500`}></i>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 p-4 z-20">
                      <h3 className="text-white text-lg font-medium">{category.name}</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
                      Explore our range of {category.name.toLowerCase()} services from top professionals.
                    </p>
                    <div className="mt-3 flex items-center text-bronze">
                      <span className="text-sm font-medium">Explore Services</span>
                      <i className="ri-arrow-right-line ml-1"></i>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </Link>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/services">
            <a className="inline-flex items-center px-6 py-3 rounded-full border-2 border-bronze text-bronze hover:bg-bronze hover:text-white transition-colors duration-300">
              <span>View All Services</span>
              <i className="ri-arrow-right-line ml-2"></i>
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}