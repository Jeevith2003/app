import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Offer } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

type OfferCardProps = {
  offer: Offer;
  onClaim?: () => void;
};

export function OfferCard({ offer, onClaim }: OfferCardProps) {
  const {
    title,
    description,
    code,
    discountType,
    discountValue,
    endDate,
    gradient,
    backgroundColor,
  } = offer;
  
  const formattedDiscount = discountType === "percentage" 
    ? `${discountValue}%` 
    : formatPrice(discountValue);
  
  const formattedDate = new Date(endDate).toLocaleDateString("en-US", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  
  let cardClasses = "rounded-xl p-4 shadow-lg";
  
  if (gradient) {
    cardClasses += ` bg-gradient-to-r ${gradient} text-white`;
  } else if (backgroundColor) {
    cardClasses += ` ${backgroundColor} border-2 border-bronze text-gray-800 dark:text-white`;
  } else {
    cardClasses += " bg-white dark:bg-gray-800 text-gray-800 dark:text-white";
  }
  
  const buttonClasses = gradient 
    ? "bg-bronze text-white hover:bg-bronze-dark" 
    : "bg-navy text-white hover:bg-navy-dark dark:bg-navy dark:hover:bg-navy-light";
  
  return (
    <Card className={cardClasses}>
      <CardContent className="p-0">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/4 flex justify-center">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center ${
              gradient ? "bg-white/20 backdrop-blur-sm" : "bg-navy/5 dark:bg-white/5"
            }`}>
              {discountType === "percentage" ? (
                <span className="text-2xl font-bold">{discountValue}%</span>
              ) : (
                <i className="ri-coupon-3-line text-bronze text-4xl"></i>
              )}
            </div>
          </div>
          <div className="md:w-2/4 text-center md:text-left mt-4 md:mt-0">
            <h4 className="text-xl font-playfair font-semibold">{title}</h4>
            <p className={`mt-1 ${gradient ? "text-white/80" : "text-gray-600 dark:text-gray-300"}`}>
              {description}
            </p>
            <p className={`text-sm mt-2 ${gradient ? "text-white/70" : "text-gray-500 dark:text-gray-400"}`}>
              {code ? `Use code: ${code}` : `Valid until: ${formattedDate}`}
            </p>
          </div>
          <div className="md:w-1/4 mt-4 md:mt-0 flex justify-center md:justify-end">
            <Button
              className={buttonClasses}
              onClick={onClaim}
            >
              {code ? "Apply" : "Claim Now"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
