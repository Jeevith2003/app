import { useState } from "react";
import { X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { formatDate, formatTime } from "@/lib/utils";

type BookingSuccessProps = {
  bookingId: string;
  serviceName: string;
  salonName: string;
  date: string;
  time: string;
  onClose: () => void;
};

export function BookingSuccess({
  bookingId,
  serviceName,
  salonName,
  date,
  time,
  onClose,
}: BookingSuccessProps) {
  const [showConfetti, setShowConfetti] = useState(true);
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      {showConfetti && (
        <div id="confetti" className="fixed inset-0 pointer-events-none animate-confetti"></div>
      )}
      <Card className="bg-white dark:bg-gray-800 rounded-xl p-6 m-4 max-w-md w-full text-center relative">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </Button>
        <div className="w-20 h-20 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="h-10 w-10 text-green-600 dark:text-green-400" />
        </div>
        <h3 className="text-xl font-playfair font-semibold dark:text-white">Booking Confirmed!</h3>
        <p className="text-gray-600 dark:text-gray-300 mt-3">
          Your appointment has been successfully booked at {salonName}.
        </p>
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 my-4">
          <div className="flex justify-between mb-2">
            <span className="text-gray-600 dark:text-gray-300">Date & Time:</span>
            <span className="font-medium dark:text-white">{formatDate(date)} • {formatTime(time)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-600 dark:text-gray-300">Service:</span>
            <span className="font-medium dark:text-white">{serviceName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-300">Booking ID:</span>
            <span className="font-medium dark:text-white">#{bookingId}</span>
          </div>
        </div>
        <div className="mt-4 space-y-3">
          <Button className="w-full bg-navy text-white hover:bg-navy-dark dark:bg-navy dark:hover:bg-navy-light">
            View Booking Details
          </Button>
          <Button 
            variant="outline" 
            className="w-full bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </Card>
    </div>
  );
}
