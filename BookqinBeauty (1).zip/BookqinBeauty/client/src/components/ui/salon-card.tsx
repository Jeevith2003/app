import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Salon } from "@shared/schema";
import { MapPin, Star } from "lucide-react";
import { Link } from "wouter";
import { truncateText } from "@/lib/utils";

type SalonCardProps = {
  salon: Salon;
  onBookNow?: () => void;
};

export function SalonCard({ salon, onBookNow }: SalonCardProps) {
  const {
    id,
    name,
    address,
    city,
    profileImage,
    coverImage,
    isVerified,
    rating,
    totalReviews,
    tags = [],
  } = salon;
  
  const handleBookNow = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onBookNow) onBookNow();
  };
  
  return (
    <Link href={`/salon/${id}`}>
      <Card className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-soft hover:shadow-md transition-all hover:scale-[1.02] cursor-pointer">
        <img
          src={coverImage || "https://images.unsplash.com/photo-1600948836101-f9ffda59d250?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300&q=80"} 
          alt={`${name} salon`}
          className="w-full h-40 object-cover"
        />
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-playfair font-semibold text-lg dark:text-white">{name}</h4>
            {isVerified && (
              <div className="flex items-center bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 px-2 py-0.5 rounded-full text-xs">
                <i className="ri-verified-badge-fill mr-1"></i>
                <span>Verified</span>
              </div>
            )}
          </div>
          <div className="flex items-center text-sm text-gray-600 dark:text-gray-300 mb-3">
            <MapPin className="h-3.5 w-3.5 mr-1" />
            <span>{truncateText(`${address}, ${city}`, 30)}</span>
          </div>
          <div className="flex items-center mb-3">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="ml-1 dark:text-white">{rating.toFixed(1)}</span>
            </div>
            <span className="mx-2 text-gray-300 dark:text-gray-600">|</span>
            <span className="text-sm text-gray-600 dark:text-gray-300">{totalReviews}+ reviews</span>
          </div>
          <div className="flex flex-wrap gap-2 mb-3">
            {tags?.slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="secondary" className="bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200 text-xs px-2 py-1 rounded-full">
                {tag}
              </Badge>
            ))}
          </div>
          <Button 
            className="w-full bg-navy text-white hover:bg-navy-dark dark:bg-navy dark:hover:bg-navy-light"
            onClick={handleBookNow}
          >
            Book Appointment
          </Button>
        </CardContent>
      </Card>
    </Link>
  );
}
