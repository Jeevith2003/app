import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Service } from "@shared/schema";
import { Clock, Star } from "lucide-react";
import { formatPrice } from "@/lib/utils";

type ServiceCardProps = {
  service: Service;
  compact?: boolean;
  onBook?: () => void;
};

export function ServiceCard({ service, compact = false, onBook }: ServiceCardProps) {
  const {
    name,
    description,
    price,
    duration,
    imageUrl,
    isPopular,
  } = service;

  if (compact) {
    return (
      <Card className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-soft hover:scale-[1.02] transition-all">
        <img
          src={imageUrl || `https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80`}
          alt={name}
          className="w-full h-32 object-cover"
        />
        <CardContent className="p-3">
          <h4 className="font-medium dark:text-white">{name}</h4>
          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{formatPrice(price)}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-soft flex flex-col md:flex-row hover:shadow-md transition-all">
      <img
        src={imageUrl || `https://images.unsplash.com/photo-1540555700478-4be289fbecef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80`}
        alt={name}
        className="w-full md:w-1/4 h-40 md:h-auto object-cover rounded-lg"
      />
      <div className="md:ml-4 mt-3 md:mt-0 flex-grow">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-playfair font-semibold text-lg dark:text-white">{name}</h3>
            <div className="flex items-center mt-1">
              {isPopular && (
                <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 text-xs px-2 py-0.5 rounded-full mr-2">
                  Trending
                </Badge>
              )}
              <span className="text-sm text-gray-600 dark:text-gray-300 flex items-center">
                <Clock className="h-3.5 w-3.5 mr-1" />
                {duration} mins
              </span>
            </div>
          </div>
          <span className="text-bronze dark:text-bronze-light font-medium">{formatPrice(price)}</span>
        </div>
        <p className="text-gray-600 dark:text-gray-300 text-sm mt-2">{description}</p>
        <div className="flex mt-3 justify-between items-center">
          <div className="flex items-center">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="ml-1 dark:text-white">4.9</span>
            </div>
            <span className="mx-2 text-gray-300 dark:text-gray-600">|</span>
            <span className="text-sm text-gray-600 dark:text-gray-300">350+ bookings</span>
          </div>
          <Button
            className="bg-navy text-white hover:bg-navy-dark dark:bg-navy dark:hover:bg-navy-light"
            onClick={onBook}
          >
            Book Now
          </Button>
        </div>
      </div>
    </Card>
  );
}
