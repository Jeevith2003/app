import React from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, MapPin, Calendar, ArrowRight } from "lucide-react";
import { Salon } from "@shared/schema";

export function FeaturedSalons() {
  // Fetch top rated salons
  const { data: salonsData, isLoading } = useQuery({
    queryKey: ['/api/salons/top'],
  });
  
  const salons: Salon[] = salonsData?.salons || [];
  
  return (
    <div className="py-16 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-playfair font-semibold text-gray-900 dark:text-white">
              Featured <span className="text-bronze">Salons</span>
            </h2>
            <p className="mt-2 text-gray-600 dark:text-gray-300 max-w-xl">
              Discover the highest-rated beauty destinations loved by our community
            </p>
          </div>
          <Link href="/salons">
            <a className="mt-4 md:mt-0 inline-flex items-center text-bronze hover:text-bronze-dark">
              <span>View All Salons</span>
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="spinner"></div>
          </div>
        ) : salons.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-600 rounded-full flex items-center justify-center mb-4">
              <i className="ri-store-2-line text-2xl text-gray-400"></i>
            </div>
            <h3 className="text-lg font-medium dark:text-white">No Salons Found</h3>
            <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
              We're currently onboarding new salons. Check back soon!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {salons.map((salon) => (
              <Link key={salon.id} href={`/salon/${salon.id}`}>
                <a className="block h-full">
                  <Card className="salon-card h-full border-none overflow-hidden">
                    <div className="relative h-48 overflow-hidden">
                      {salon.isPromoted && (
                        <Badge className="absolute top-3 left-3 z-10 bg-bronze text-white border-none">
                          Featured
                        </Badge>
                      )}
                      {salon.coverImage ? (
                        <img 
                          src={salon.coverImage} 
                          alt={salon.name} 
                          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-r from-navy/80 to-navy-light/80 flex items-center justify-center">
                          <span className="text-2xl font-playfair text-white">{salon.name.charAt(0)}</span>
                        </div>
                      )}
                    </div>
                    
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-medium text-gray-900 dark:text-white">{salon.name}</h3>
                          <div className="flex items-center mt-1 text-gray-500 dark:text-gray-400 text-sm">
                            <MapPin className="h-3.5 w-3.5 mr-1" />
                            <span className="truncate">{salon.city}, {salon.state}</span>
                          </div>
                        </div>
                        <div className="flex items-center bg-gray-50 dark:bg-gray-700 px-2 py-1 rounded-md">
                          <Star className="h-3.5 w-3.5 text-yellow-400 mr-1" />
                          <span className="text-sm font-medium">{salon.rating || '0'}</span>
                        </div>
                      </div>
                      
                      <div className="mt-3 flex flex-wrap gap-1">
                        {salon.tags && salon.tags.slice(0, 3).map((tag, index) => (
                          <span 
                            key={index}
                            className="inline-block bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs px-2 py-1 rounded-md"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                      
                      <div className="mt-4 flex justify-between items-center">
                        <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                          <Calendar className="h-3.5 w-3.5 mr-1" />
                          <span>Available Today</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-bronze hover:text-bronze-dark hover:bg-transparent"
                        >
                          Book Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </a>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}