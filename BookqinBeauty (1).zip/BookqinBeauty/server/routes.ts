import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./pg-storage"; // Use PostgreSQL storage instead of memory storage
import { z } from "zod";
import { bookingStatuses, insertBookingSchema, insertCustomerSchema, insertReviewSchema, insertSalonSchema, insertServiceSchema, insertUserSchema, loginSchema } from "@shared/schema";
import { hashPassword, comparePassword, generateToken, verifyToken } from "./auth";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";

const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  app.use(session({
    secret: process.env.SESSION_SECRET || "bookqin-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }, // 24 hours
    store: new SessionStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    })
  }));

  // Passport setup
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport local strategy
  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return done(null, false, { message: "Invalid username or password" });
      }

      const isMatch = await comparePassword(password, user.password);
      if (!isMatch) {
        return done(null, false, { message: "Invalid username or password" });
      }

      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }));

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  const requireCustomer = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated() || (req.user as any).userType !== "customer") {
      return res.status(403).json({ message: "Forbidden - Customer access only" });
    }
    next();
  };

  const requireSalon = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated() || (req.user as any).userType !== "client") {
      return res.status(403).json({ message: "Forbidden - Salon access only" });
    }
    next();
  };

  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }

      // Hash password
      const hashedPassword = await hashPassword(userData.password);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Create profile based on user type
      if (userData.userType === "customer") {
        const customerData = insertCustomerSchema.parse(req.body.profile);
        await storage.createCustomer({
          ...customerData,
          userId: user.id
        });
      } else if (userData.userType === "client") {
        const salonData = insertSalonSchema.parse(req.body.profile);
        await storage.createSalon({
          ...salonData,
          userId: user.id
        });
      }

      // Login the user
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in after registration" });
        }
        
        // Return user data without password
        const { password, ...userWithoutPassword } = user;
        return res.status(201).json({
          message: "Registration successful",
          user: userWithoutPassword
        });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      
      return res.status(500).json({ message: "Registration failed", error: error.message });
    }
  });

  app.post('/api/auth/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info.message || "Authentication failed" });
      }
      
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        
        // Return user data without password
        const { password, ...userWithoutPassword } = user;
        return res.json({
          message: "Login successful",
          user: userWithoutPassword
        });
      });
    })(req, res, next);
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get('/api/auth/session', (req, res) => {
    if (req.isAuthenticated()) {
      const { password, ...userWithoutPassword } = req.user as any;
      res.json({ authenticated: true, user: userWithoutPassword });
    } else {
      res.json({ authenticated: false });
    }
  });

  // User profile routes
  app.get('/api/user/profile', requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      
      let profile;
      if (user.userType === "customer") {
        profile = await storage.getCustomerByUserId(user.id);
      } else if (user.userType === "client") {
        profile = await storage.getSalonByUserId(user.id);
      }
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      res.json({ profile });
    } catch (error) {
      res.status(500).json({ message: "Error fetching profile", error: error.message });
    }
  });

  // Customer routes
  app.get('/api/customer/salons', async (req, res) => {
    try {
      const salons = await storage.getAllSalons();
      res.json({ salons });
    } catch (error) {
      res.status(500).json({ message: "Error fetching salons", error: error.message });
    }
  });

  app.get('/api/customer/services/popular', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const services = await storage.getPopularServices(limit);
      res.json({ services });
    } catch (error) {
      res.status(500).json({ message: "Error fetching popular services", error: error.message });
    }
  });

  app.get('/api/customer/salon/:salonId/services', async (req, res) => {
    try {
      const salonId = parseInt(req.params.salonId);
      const services = await storage.getServicesBySalonId(salonId);
      res.json({ services });
    } catch (error) {
      res.status(500).json({ message: "Error fetching salon services", error: error.message });
    }
  });

  app.post('/api/customer/bookings', requireCustomer, async (req, res) => {
    try {
      const user = req.user as any;
      const customer = await storage.getCustomerByUserId(user.id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer profile not found" });
      }
      
      const bookingData = insertBookingSchema.parse({
        ...req.body,
        customerId: customer.id
      });
      
      const booking = await storage.createBooking(bookingData);
      res.status(201).json({ booking });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      
      res.status(500).json({ message: "Error creating booking", error: error.message });
    }
  });

  app.get('/api/customer/bookings', requireCustomer, async (req, res) => {
    try {
      const user = req.user as any;
      const customer = await storage.getCustomerByUserId(user.id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer profile not found" });
      }
      
      const bookings = await storage.getBookingsByCustomerId(customer.id);
      res.json({ bookings });
    } catch (error) {
      res.status(500).json({ message: "Error fetching bookings", error: error.message });
    }
  });

  app.post('/api/customer/reviews', requireCustomer, async (req, res) => {
    try {
      const user = req.user as any;
      const customer = await storage.getCustomerByUserId(user.id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer profile not found" });
      }
      
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        customerId: customer.id
      });
      
      const review = await storage.createReview(reviewData);
      res.status(201).json({ review });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      
      res.status(500).json({ message: "Error creating review", error: error.message });
    }
  });

  // Salon routes
  app.post('/api/salon/services', requireSalon, async (req, res) => {
    try {
      const user = req.user as any;
      const salon = await storage.getSalonByUserId(user.id);
      
      if (!salon) {
        return res.status(404).json({ message: "Salon profile not found" });
      }
      
      const serviceData = insertServiceSchema.parse({
        ...req.body,
        salonId: salon.id
      });
      
      const service = await storage.createService(serviceData);
      res.status(201).json({ service });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      
      res.status(500).json({ message: "Error creating service", error: error.message });
    }
  });

  app.get('/api/salon/services', requireSalon, async (req, res) => {
    try {
      const user = req.user as any;
      const salon = await storage.getSalonByUserId(user.id);
      
      if (!salon) {
        return res.status(404).json({ message: "Salon profile not found" });
      }
      
      const services = await storage.getServicesBySalonId(salon.id);
      res.json({ services });
    } catch (error) {
      res.status(500).json({ message: "Error fetching services", error: error.message });
    }
  });

  app.get('/api/salon/bookings', requireSalon, async (req, res) => {
    try {
      const user = req.user as any;
      const salon = await storage.getSalonByUserId(user.id);
      
      if (!salon) {
        return res.status(404).json({ message: "Salon profile not found" });
      }
      
      const bookings = await storage.getBookingsBySalonId(salon.id);
      res.json({ bookings });
    } catch (error) {
      res.status(500).json({ message: "Error fetching bookings", error: error.message });
    }
  });

  app.patch('/api/salon/bookings/:id/status', requireSalon, async (req, res) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!bookingId || !status || !bookingStatuses.includes(status)) {
        return res.status(400).json({ message: "Invalid booking ID or status" });
      }
      
      const booking = await storage.updateBookingStatus(bookingId, status);
      res.json({ booking });
    } catch (error) {
      res.status(500).json({ message: "Error updating booking status", error: error.message });
    }
  });

  app.get('/api/salon/reviews', requireSalon, async (req, res) => {
    try {
      const user = req.user as any;
      const salon = await storage.getSalonByUserId(user.id);
      
      if (!salon) {
        return res.status(404).json({ message: "Salon profile not found" });
      }
      
      const reviews = await storage.getReviewsBySalonId(salon.id);
      res.json({ reviews });
    } catch (error) {
      res.status(500).json({ message: "Error fetching reviews", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
