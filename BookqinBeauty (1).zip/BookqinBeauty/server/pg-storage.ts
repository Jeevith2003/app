import { and, eq, desc, isNull, sql } from 'drizzle-orm';
import { db, schema } from './db';
import { 
  User, Customer, Salon, Service, Booking, 
  Review, InsertUser, InsertCustomer, InsertSalon, 
  InsertService, InsertBooking, InsertReview,
  BookingStatus
} from '@shared/schema';
import { IStorage } from './storage';

export class PgStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const users = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.id, id))
      .limit(1);
    return users[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.username, username))
      .limit(1);
    return users[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const users = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.email, email))
      .limit(1);
    return users[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const createdUsers = await db
      .insert(schema.users)
      .values({
        ...user,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return createdUsers[0];
  }

  // Customer operations
  async getCustomerByUserId(userId: number): Promise<Customer | undefined> {
    const customers = await db
      .select()
      .from(schema.customers)
      .where(eq(schema.customers.userId, userId))
      .limit(1);
    return customers[0];
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const createdCustomers = await db
      .insert(schema.customers)
      .values(customer)
      .returning();
    return createdCustomers[0];
  }

  async updateCustomerWallet(customerId: number, amount: number): Promise<Customer> {
    const customer = await db
      .select()
      .from(schema.customers)
      .where(eq(schema.customers.id, customerId))
      .limit(1)
      .then(res => res[0]);

    if (!customer) {
      throw new Error("Customer not found");
    }

    const newBalance = (customer.walletBalance || 0) + amount;

    const updatedCustomers = await db
      .update(schema.customers)
      .set({ walletBalance: newBalance })
      .where(eq(schema.customers.id, customerId))
      .returning();

    return updatedCustomers[0];
  }

  // Salon operations
  async getSalonByUserId(userId: number): Promise<Salon | undefined> {
    const salons = await db
      .select()
      .from(schema.salons)
      .where(eq(schema.salons.userId, userId))
      .limit(1);
    return salons[0];
  }

  async createSalon(salon: InsertSalon): Promise<Salon> {
    const createdSalons = await db
      .insert(schema.salons)
      .values({
        ...salon,
        rating: 0,
        totalRating: 0,
        totalReviews: 0,
        location: null // Add default location as null
      })
      .returning();
    return createdSalons[0];
  }

  async getAllSalons(): Promise<Salon[]> {
    return db
      .select()
      .from(schema.salons);
  }

  async getTopRatedSalons(limit: number): Promise<Salon[]> {
    return db
      .select()
      .from(schema.salons)
      .orderBy(desc(schema.salons.rating))
      .limit(limit);
  }

  async getNearBySalons(lat: number, lng: number, radius: number): Promise<Salon[]> {
    // This is a simplistic implementation without actual geo calculations
    // In a real app, we'd use PostGIS for proper geo-queries
    return db
      .select()
      .from(schema.salons)
      .limit(10);
  }

  // Service operations
  async createService(service: InsertService): Promise<Service> {
    const createdServices = await db
      .insert(schema.services)
      .values(service)
      .returning();
    return createdServices[0];
  }

  async getServicesBySalonId(salonId: number): Promise<Service[]> {
    return db
      .select()
      .from(schema.services)
      .where(eq(schema.services.salonId, salonId));
  }

  async getPopularServices(limit: number): Promise<Service[]> {
    return db
      .select()
      .from(schema.services)
      .where(eq(schema.services.isPopular, true))
      .limit(limit);
  }

  async getServiceById(id: number): Promise<Service | undefined> {
    const services = await db
      .select()
      .from(schema.services)
      .where(eq(schema.services.id, id))
      .limit(1);
    return services[0];
  }

  // Booking operations
  async createBooking(booking: InsertBooking): Promise<Booking> {
    const createdBookings = await db
      .insert(schema.bookings)
      .values({
        ...booking,
        bookingId: `BK${Date.now()}`,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return createdBookings[0];
  }

  async getBookingsByCustomerId(customerId: number): Promise<Booking[]> {
    return db
      .select()
      .from(schema.bookings)
      .where(eq(schema.bookings.customerId, customerId))
      .orderBy(desc(schema.bookings.createdAt));
  }

  async getBookingsBySalonId(salonId: number): Promise<Booking[]> {
    return db
      .select()
      .from(schema.bookings)
      .where(eq(schema.bookings.salonId, salonId))
      .orderBy(desc(schema.bookings.createdAt));
  }

  async updateBookingStatus(bookingId: number, status: BookingStatus): Promise<Booking> {
    const updatedBookings = await db
      .update(schema.bookings)
      .set({ 
        status,
        updatedAt: new Date()
      })
      .where(eq(schema.bookings.id, bookingId))
      .returning();
    return updatedBookings[0];
  }

  // Review operations
  async createReview(review: InsertReview): Promise<Review> {
    // Create the review
    const createdReviews = await db
      .insert(schema.reviews)
      .values({
        ...review,
        createdAt: new Date()
      })
      .returning();
    
    // Update salon ratings
    const salon = await db
      .select()
      .from(schema.salons)
      .where(eq(schema.salons.id, review.salonId))
      .limit(1)
      .then(res => res[0]);
    
    if (salon) {
      const totalRating = (salon.totalRating || 0) + review.rating;
      const totalReviews = (salon.totalReviews || 0) + 1;
      const newRating = totalRating / totalReviews;
      
      await db
        .update(schema.salons)
        .set({ 
          rating: newRating,
          totalRating,
          totalReviews
        })
        .where(eq(schema.salons.id, review.salonId));
    }
    
    return createdReviews[0];
  }

  async getReviewsBySalonId(salonId: number): Promise<Review[]> {
    return db
      .select()
      .from(schema.reviews)
      .where(eq(schema.reviews.salonId, salonId))
      .orderBy(desc(schema.reviews.createdAt));
  }
}

// Create and export storage instance
export const storage = new PgStorage();