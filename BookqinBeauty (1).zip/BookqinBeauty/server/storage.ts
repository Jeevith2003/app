import { 
  users, User, InsertUser, UserType,
  customers, Customer, InsertCustomer,
  salons, Salon, InsertSalon,
  serviceCategories, services, Service, InsertService,
  addons, staff, timeSlots, bookings, Booking, InsertBooking, BookingStatus,
  reviews, Review, InsertReview, offers, walletTransactions, notifications,
  chatSessions
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Customer operations
  getCustomerByUserId(userId: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomerWallet(customerId: number, amount: number): Promise<Customer>;
  
  // Salon operations
  getSalonByUserId(userId: number): Promise<Salon | undefined>;
  createSalon(salon: InsertSalon): Promise<Salon>;
  getAllSalons(): Promise<Salon[]>;
  getTopRatedSalons(limit: number): Promise<Salon[]>;
  getNearBySalons(lat: number, lng: number, radius: number): Promise<Salon[]>;
  
  // Service operations
  createService(service: InsertService): Promise<Service>;
  getServicesBySalonId(salonId: number): Promise<Service[]>;
  getPopularServices(limit: number): Promise<Service[]>;
  getServiceById(id: number): Promise<Service | undefined>;
  
  // Booking operations
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingsByCustomerId(customerId: number): Promise<Booking[]>;
  getBookingsBySalonId(salonId: number): Promise<Booking[]>;
  updateBookingStatus(bookingId: number, status: BookingStatus): Promise<Booking>;
  
  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getReviewsBySalonId(salonId: number): Promise<Review[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private customers: Map<number, Customer>;
  private salons: Map<number, Salon>;
  private serviceCategories: Map<number, any>;
  private services: Map<number, Service>;
  private addons: Map<number, any>;
  private staff: Map<number, any>;
  private timeSlots: Map<number, any>;
  private bookings: Map<number, Booking>;
  private reviews: Map<number, Review>;
  private offers: Map<number, any>;
  private walletTransactions: Map<number, any>;
  private notifications: Map<number, any>;
  private chatSessions: Map<number, any>;
  
  private userId: number;
  private customerId: number;
  private salonId: number;
  private serviceCategoryId: number;
  private serviceId: number;
  private addonId: number;
  private staffId: number;
  private timeSlotId: number;
  private bookingId: number;
  private reviewId: number;
  private offerId: number;
  private walletTransactionId: number;
  private notificationId: number;
  private chatSessionId: number;
  
  constructor() {
    // Initialize maps
    this.users = new Map();
    this.customers = new Map();
    this.salons = new Map();
    this.serviceCategories = new Map();
    this.services = new Map();
    this.addons = new Map();
    this.staff = new Map();
    this.timeSlots = new Map();
    this.bookings = new Map();
    this.reviews = new Map();
    this.offers = new Map();
    this.walletTransactions = new Map();
    this.notifications = new Map();
    this.chatSessions = new Map();
    
    // Initialize IDs
    this.userId = 1;
    this.customerId = 1;
    this.salonId = 1;
    this.serviceCategoryId = 1;
    this.serviceId = 1;
    this.addonId = 1;
    this.staffId = 1;
    this.timeSlotId = 1;
    this.bookingId = 1;
    this.reviewId = 1;
    this.offerId = 1;
    this.walletTransactionId = 1;
    this.notificationId = 1;
    this.chatSessionId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }
  
  private initializeSampleData() {
    // Service categories
    const categories = [
      { id: this.serviceCategoryId++, name: "Hair", icon: "ri-scissors-line", imageUrl: "https://images.unsplash.com/photo-1560066984-138dadb4c035" },
      { id: this.serviceCategoryId++, name: "Makeup", icon: "ri-brush-line", imageUrl: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2" },
      { id: this.serviceCategoryId++, name: "Spa", icon: "ri-emotion-happy-line", imageUrl: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874" },
      { id: this.serviceCategoryId++, name: "Nail Care", icon: "ri-hand-heart-line", imageUrl: "https://images.unsplash.com/photo-1604654894610-df63bc536371" }
    ];
    
    categories.forEach(cat => this.serviceCategories.set(cat.id, cat));
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }
  
  // Customer operations
  async getCustomerByUserId(userId: number): Promise<Customer | undefined> {
    return Array.from(this.customers.values()).find(
      (customer) => customer.userId === userId
    );
  }
  
  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.customerId++;
    const customer: Customer = { 
      ...insertCustomer, 
      id,
      gender: insertCustomer.gender || null,
      dateOfBirth: insertCustomer.dateOfBirth || null,
      profileImage: insertCustomer.profileImage || null,
      walletBalance: insertCustomer.walletBalance || 0
    };
    this.customers.set(id, customer);
    return customer;
  }
  
  async updateCustomerWallet(customerId: number, amount: number): Promise<Customer> {
    const customer = this.customers.get(customerId);
    if (!customer) {
      throw new Error("Customer not found");
    }
    
    const updatedCustomer = {
      ...customer,
      walletBalance: (customer.walletBalance || 0) + amount
    };
    
    this.customers.set(customerId, updatedCustomer);
    return updatedCustomer;
  }
  
  // Salon operations
  async getSalonByUserId(userId: number): Promise<Salon | undefined> {
    return Array.from(this.salons.values()).find(
      (salon) => salon.userId === userId
    );
  }
  
  async createSalon(insertSalon: InsertSalon): Promise<Salon> {
    const id = this.salonId++;
    const salon: Salon = { 
      ...insertSalon, 
      id,
      rating: 0,
      totalRating: 0,
      totalReviews: 0,
      description: insertSalon.description || null,
      profileImage: insertSalon.profileImage || null,
      coverImage: null,
      location: {},
      email: insertSalon.email || null,
      website: null,
      openingTime: null,
      closingTime: null,
      isHomeServiceAvailable: false,
      acceptsOnlineBooking: true,
      isVerified: false,
      tags: insertSalon.tags || null
    };
    this.salons.set(id, salon);
    return salon;
  }
  
  async getAllSalons(): Promise<Salon[]> {
    return Array.from(this.salons.values());
  }
  
  async getTopRatedSalons(limit: number): Promise<Salon[]> {
    return Array.from(this.salons.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }
  
  async getNearBySalons(lat: number, lng: number, radius: number): Promise<Salon[]> {
    // In a real implementation, this would use geospatial queries
    // For simplicity, we'll just return all salons
    return Array.from(this.salons.values());
  }
  
  // Service operations
  async createService(insertService: InsertService): Promise<Service> {
    const id = this.serviceId++;
    const service: Service = { 
      ...insertService, 
      id,
      description: insertService.description || null,
      gender: insertService.gender || null,
      tags: insertService.tags || null,
      imageUrl: insertService.imageUrl || null,
      categoryId: insertService.categoryId || null,
      isPopular: insertService.isPopular || false
    };
    this.services.set(id, service);
    return service;
  }
  
  async getServicesBySalonId(salonId: number): Promise<Service[]> {
    return Array.from(this.services.values()).filter(
      (service) => service.salonId === salonId
    );
  }
  
  async getPopularServices(limit: number): Promise<Service[]> {
    return Array.from(this.services.values())
      .filter(service => service.isPopular)
      .slice(0, limit);
  }
  
  async getServiceById(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }
  
  // Booking operations
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.bookingId++;
    // Generate a booking ID like BK12345
    const bookingIdStr = `BK${String(id).padStart(5, '0')}`;
    
    const now = new Date();
    
    const booking: Booking = { 
      ...insertBooking, 
      id,
      bookingId: bookingIdStr,
      createdAt: now,
      updatedAt: now,
      status: insertBooking.status || "pending",
      staffId: insertBooking.staffId || null,
      addonIds: insertBooking.addonIds || null,
      notes: insertBooking.notes || null
    };
    
    this.bookings.set(id, booking);
    return booking;
  }
  
  async getBookingsByCustomerId(customerId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      (booking) => booking.customerId === customerId
    );
  }
  
  async getBookingsBySalonId(salonId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      (booking) => booking.salonId === salonId
    );
  }
  
  async updateBookingStatus(bookingId: number, status: BookingStatus): Promise<Booking> {
    const booking = this.bookings.get(bookingId);
    if (!booking) {
      throw new Error("Booking not found");
    }
    
    const updatedBooking = {
      ...booking,
      status,
      updatedAt: new Date()
    };
    
    this.bookings.set(bookingId, updatedBooking);
    return updatedBooking;
  }
  
  // Review operations
  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.reviewId++;
    const now = new Date();
    
    const review: Review = { 
      ...insertReview, 
      id,
      createdAt: now,
      bookingId: insertReview.bookingId || null,
      comment: insertReview.comment || null
    };
    
    this.reviews.set(id, review);
    
    // Update salon rating
    const salon = this.salons.get(insertReview.salonId);
    if (salon) {
      const newTotalRating = salon.totalRating + insertReview.rating;
      const newTotalReviews = salon.totalReviews + 1;
      const newRating = newTotalRating / newTotalReviews;
      
      this.salons.set(salon.id, {
        ...salon,
        rating: newRating,
        totalRating: newTotalRating,
        totalReviews: newTotalReviews
      });
    }
    
    return review;
  }
  
  async getReviewsBySalonId(salonId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      (review) => review.salonId === salonId
    );
  }
}

// Export a singleton instance
export const storage = new MemStorage();
