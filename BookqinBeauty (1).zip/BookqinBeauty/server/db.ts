import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '../shared/schema';

// Create postgres connection
const client = postgres(process.env.DATABASE_URL!);

// Create drizzle client
export const db = drizzle(client, { schema });

// Exporting schema for convenience
export { schema };