// Database migration script for Bookqin
// Run with: node migrate.js

const { migrate } = require('drizzle-orm/postgres-js/migrator');
const postgres = require('postgres');
const { drizzle } = require('drizzle-orm/postgres-js');

// Create postgres connection
const migrationClient = postgres(process.env.DATABASE_URL);

// Create drizzle client for migrations
const db = drizzle(migrationClient);

async function runMigration() {
  console.log('Starting database migration...');
  
  try {
    // This will auto-generate migrations based on schema differences
    await migrate(db, { migrationsFolder: './migrations' });
    console.log('Migration completed successfully!');
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  } finally {
    // Close the database connection
    await migrationClient.end();
  }
}

runMigration();