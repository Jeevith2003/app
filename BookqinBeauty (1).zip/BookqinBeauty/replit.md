# Bookqin - Beauty Services Booking Platform

## Overview

Bookqin is a full-stack web application for booking beauty services. The platform connects customers with salons, allowing them to browse services, make appointments, and manage bookings. Salon owners can manage their business through a dedicated interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

Bookqin uses a modern full-stack architecture with:

1. **Frontend**:
   - React with TypeScript
   - Tailwind CSS with shadcn/ui components
   - Wouter for client-side routing
   - TanStack Query for data fetching
   - Responsive design for mobile and desktop

2. **Backend**:
   - Express.js server
   - REST API endpoints
   - JWT-based authentication
   - Session management

3. **Database**:
   - PostgreSQL (currently implemented with Drizzle ORM but without a specific database provider)
   - Schema defined in shared/schema.ts

4. **Deployment**:
   - Configured for deployment on Replit
   - Production build using Vite

## Key Components

### User Authentication System

- Supports two user types: "customer" and "client" (salon owners)
- JWT token-based authentication
- Password hashing with bcryptjs
- Login, registration, and session management

### Customer Interface

1. **Home Page**:
   - Browse popular services and nearby salons
   - Search functionality
   - Special offers display

2. **Salon Browsing**:
   - View salon profiles with services, ratings, and information
   - Filter salons by location, service type, and ratings

3. **Booking System**:
   - Select services, date, and time
   - Choose between salon visits or home services
   - Add special instructions

4. **User Profile**:
   - Manage personal information
   - Wallet for payments
   - Booking history

5. **AI Style Recommendation**:
   - Upload photos to get personalized style recommendations

### Salon Owner Interface

1. **Dashboard**:
   - Overview of business metrics, bookings, and earnings
   - Daily schedule at a glance

2. **Booking Management**:
   - Accept, reject, or reschedule bookings
   - View customer details and booking history

3. **Service Management**:
   - Add, edit, or remove services
   - Set pricing and duration
   - Categorize services

4. **Staff Management**:
   - Add staff members
   - Assign services to staff

5. **Earnings and Analytics**:
   - Track revenue and bookings
   - View performance metrics

6. **Salon Profile Management**:
   - Update business information
   - Upload photos
   - Set working hours

### Shared Components

1. **UI Components**: 
   - Built with shadcn/ui component library
   - Custom components like ServiceCard, SalonCard, BookingSuccess

2. **State Management**:
   - React Query for server state
   - Context API for application state (auth, theme)

3. **Utilities**:
   - Date and time formatting
   - Currency formatting
   - Form validation with Zod

## Data Flow

1. **Authentication Flow**:
   - User submits login/register form
   - Server validates credentials and creates JWT token
   - Token stored in client-side session
   - Auth context provides user state throughout the application

2. **Booking Flow**:
   - Customer browses and selects salon/service
   - Selects date, time, and other booking details
   - Confirms booking, which is sent to server
   - Salon owner receives notification and can manage the booking

3. **Data Fetching**:
   - TanStack Query manages API calls and caching
   - Central apiRequest utility for consistent API interactions
   - Server endpoints follow RESTful conventions

## External Dependencies

### Frontend Libraries
- React and React DOM
- TanStack Query for data fetching
- Wouter for routing
- Radix UI components (via shadcn/ui)
- Tailwind CSS for styling
- Lucide React for icons
- React Hook Form with Zod for form validation
- Recharts for dashboard visualizations

### Backend Libraries
- Express.js for server
- Drizzle ORM for database operations
- bcryptjs for password hashing
- JWT for authentication tokens
- Express session for session management

## Deployment Strategy

The application is configured for deployment on Replit with:

1. **Build Process**:
   - Frontend: Vite builds optimized assets
   - Backend: esbuild bundles server code
   - Combined build outputted to dist directory

2. **Environment Configuration**:
   - Development mode with hot reloading
   - Production mode with optimized builds
   - Environment variables for sensitive configuration

3. **Database Connection**:
   - Uses DATABASE_URL environment variable
   - Ready to be connected to a PostgreSQL database

4. **Runtime**:
   - Node.js runtime environment
   - Express server serves both API and static frontend